<?php

use Magento\Framework\App\Bootstrap;
require '../app/bootstrap.php';
ini_set('display_errors', 1);
$params = $_SERVER;
$bootstrap = Bootstrap::create(BP, $params);
$objectManager = $bootstrap->getObjectManager();
$state = $objectManager->get('Magento\Framework\App\State');
$state->setAreaCode('frontend');
$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$childIds = $objectManager->get('Magento\ConfigurableProduct\Model\Product\Type\Configurable')->getChildrenIds('161843');
$productIds = $childIds[0];
$productIds = ['142687'];
$indexLists = ['catalog_category_product', 'catalog_product_category', 'catalog_product_attribute', 'cataloginventory_stock', 'catalogsearch_fulltext', 'catalog_product_price', 'catalogrule_product', 'catalogrule_rule'];
foreach ($indexLists as $indexList) {

    $categoryIndexer = $objectManager->get('Magento\Framework\Indexer\IndexerRegistry')->get($indexList);
    //if (!$categoryIndexer->isScheduled()) {

    try {
        /*echo "<pre>";
        print_r($productIds);exit;*/
        $categoryIndexer->reindexList(array_unique($productIds));
        echo "test" . '<br>';
    } catch (\Exception $e) {
        echo $e->getMessage();
    }
    //}
}
echo "successfully";



Exto Base module [www.exto.io](https://exto.io)
=============
Magento 2 Base module by Exto provides news feeds for product and marketing updates. 
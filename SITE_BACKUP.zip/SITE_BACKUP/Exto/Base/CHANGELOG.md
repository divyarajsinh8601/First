1.1.0
=============
+ Improved tracking and integration facilities
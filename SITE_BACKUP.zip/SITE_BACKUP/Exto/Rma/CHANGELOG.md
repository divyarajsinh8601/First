1.0.1
=============
+ Implements integration API
* Minor bugfixes
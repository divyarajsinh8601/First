<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Material\Api\Data;

interface MaterialInterface
{

    const MATERIAL_NAME = 'material_name';
    const UPDATED_TIME = 'updated_time';
    const CREATED_TIME = 'created_time';
    const MATERIAL_ID = 'material_id';
    const MATERIAL_CONTENT = 'material_content';

    /**
     * Get material_id
     * @return string|null
     */
    public function getMaterialId();

    /**
     * Set material_id
     * @param string $materialId
     * @return \PavingSuperstore\Material\Material\Api\Data\MaterialInterface
     */
    public function setMaterialId($materialId);

    /**
     * Get material_name
     * @return string|null
     */
    public function getMaterialName();

    /**
     * Set material_name
     * @param string $materialName
     * @return \PavingSuperstore\Material\Material\Api\Data\MaterialInterface
     */
    public function setMaterialName($materialName);

    /**
     * Get material_content
     * @return string|null
     */
    public function getMaterialContent();

    /**
     * Set material_content
     * @param string $materialContent
     * @return \PavingSuperstore\Material\Material\Api\Data\MaterialInterface
     */
    public function setMaterialContent($materialContent);

    /**
     * Get created_time
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * Set created_time
     * @param string $createdTime
     * @return \PavingSuperstore\Material\Material\Api\Data\MaterialInterface
     */
    public function setCreatedTime($createdTime);

    /**
     * Get updated_time
     * @return string|null
     */
    public function getUpdatedTime();

    /**
     * Set updated_time
     * @param string $updatedTime
     * @return \PavingSuperstore\Material\Material\Api\Data\MaterialInterface
     */
    public function setUpdatedTime($updatedTime);
}


<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Material\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface MaterialRepositoryInterface
{

    /**
     * Save Material
     * @param \PavingSuperstore\Material\Api\Data\MaterialInterface $material
     * @return \PavingSuperstore\Material\Api\Data\MaterialInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \PavingSuperstore\Material\Api\Data\MaterialInterface $material
    );

    /**
     * Retrieve Material
     * @param string $materialId
     * @return \PavingSuperstore\Material\Api\Data\MaterialInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($materialId);

    /**
     * Retrieve Material matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \PavingSuperstore\Material\Api\Data\MaterialSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Material
     * @param \PavingSuperstore\Material\Api\Data\MaterialInterface $material
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \PavingSuperstore\Material\Api\Data\MaterialInterface $material
    );

    /**
     * Delete Material by ID
     * @param string $materialId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($materialId);
}


<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Material\Model;

use Magento\Framework\Model\AbstractModel;
use PavingSuperstore\Material\Api\Data\MaterialInterface;

class Material extends AbstractModel implements MaterialInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\PavingSuperstore\Material\Model\ResourceModel\Material::class);
    }

    /**
     * @inheritDoc
     */
    public function getMaterialId()
    {
        return $this->getData(self::MATERIAL_ID);
    }

    /**
     * @inheritDoc
     */
    public function setMaterialId($materialId)
    {
        return $this->setData(self::MATERIAL_ID, $materialId);
    }

    /**
     * @inheritDoc
     */
    public function getMaterialName()
    {
        return $this->getData(self::MATERIAL_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setMaterialName($materialName)
    {
        return $this->setData(self::MATERIAL_NAME, $materialName);
    }

    /**
     * @inheritDoc
     */
    public function getMaterialContent()
    {
        return $this->getData(self::MATERIAL_CONTENT);
    }

    /**
     * @inheritDoc
     */
    public function setMaterialContent($materialContent)
    {
        return $this->setData(self::MATERIAL_CONTENT, $materialContent);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedTime()
    {
        return $this->getData(self::CREATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedTime($createdTime)
    {
        return $this->setData(self::CREATED_TIME, $createdTime);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedTime()
    {
        return $this->getData(self::UPDATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedTime($updatedTime)
    {
        return $this->setData(self::UPDATED_TIME, $updatedTime);
    }
}


<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Material\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use PavingSuperstore\Material\Api\Data\MaterialInterface;
use PavingSuperstore\Material\Api\Data\MaterialInterfaceFactory;
use PavingSuperstore\Material\Api\Data\MaterialSearchResultsInterfaceFactory;
use PavingSuperstore\Material\Api\MaterialRepositoryInterface;
use PavingSuperstore\Material\Model\ResourceModel\Material as ResourceMaterial;
use PavingSuperstore\Material\Model\ResourceModel\Material\CollectionFactory as MaterialCollectionFactory;

class MaterialRepository implements MaterialRepositoryInterface
{

    /**
     * @var Material
     */
    protected $searchResultsFactory;

    /**
     * @var MaterialCollectionFactory
     */
    protected $materialCollectionFactory;

    /**
     * @var ResourceMaterial
     */
    protected $resource;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var MaterialInterfaceFactory
     */
    protected $materialFactory;


    /**
     * @param ResourceMaterial $resource
     * @param MaterialInterfaceFactory $materialFactory
     * @param MaterialCollectionFactory $materialCollectionFactory
     * @param MaterialSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceMaterial $resource,
        MaterialInterfaceFactory $materialFactory,
        MaterialCollectionFactory $materialCollectionFactory,
        MaterialSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->materialFactory = $materialFactory;
        $this->materialCollectionFactory = $materialCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(MaterialInterface $material)
    {
        try {
            $this->resource->save($material);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the material: %1',
                $exception->getMessage()
            ));
        }
        return $material;
    }

    /**
     * @inheritDoc
     */
    public function get($materialId)
    {
        $material = $this->materialFactory->create();
        $this->resource->load($material, $materialId);
        if (!$material->getId()) {
            throw new NoSuchEntityException(__('Material with id "%1" does not exist.', $materialId));
        }
        return $material;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->materialCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(MaterialInterface $material)
    {
        try {
            $materialModel = $this->materialFactory->create();
            $this->resource->load($materialModel, $material->getMaterialId());
            $this->resource->delete($materialModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Material: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($materialId)
    {
        return $this->delete($this->get($materialId));
    }
}


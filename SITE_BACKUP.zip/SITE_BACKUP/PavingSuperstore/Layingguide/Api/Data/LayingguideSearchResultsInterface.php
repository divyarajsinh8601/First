<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Layingguide\Api\Data;

interface LayingguideSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Layingguide list.
     * @return \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface[]
     */
    public function getItems();

    /**
     * Set layingguide_name list.
     * @param \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}


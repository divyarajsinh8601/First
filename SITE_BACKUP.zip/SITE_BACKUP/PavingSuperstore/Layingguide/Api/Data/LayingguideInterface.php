<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Layingguide\Api\Data;

interface LayingguideInterface
{

    const FILE = 'file';
    const LAYINGGUIDE_ID = 'id';
    const LAYINGGUIDE_NAME = 'laying_guide_attr';

    /**
     * Get layingguide_id
     * @return string|null
     */
    public function getLayingguideId();

    /**
     * Set layingguide_id
     * @param string $layingguideId
     * @return \PavingSuperstore\Layingguide\Layingguide\Api\Data\LayingguideInterface
     */
    public function setLayingguideId($layingguideId);

    /**
     * Get layingguide_name
     * @return string|null
     */
    public function getLayingguideName();

    /**
     * Set layingguide_name
     * @param string $layingguideName
     * @return \PavingSuperstore\Layingguide\Layingguide\Api\Data\LayingguideInterface
     */
    public function setLayingguideName($layingguideName);

    /**
     * Get file
     * @return string|null
     */
    public function getFile();

    /**
     * Set file
     * @param string $file
     * @return \PavingSuperstore\Layingguide\Layingguide\Api\Data\LayingguideInterface
     */
    public function setFile($file);
}


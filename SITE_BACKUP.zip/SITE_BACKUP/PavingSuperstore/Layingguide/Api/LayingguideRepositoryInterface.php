<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Layingguide\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface LayingguideRepositoryInterface
{

    /**
     * Save Layingguide
     * @param \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface $layingguide
     * @return \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface $layingguide
    );

    /**
     * Retrieve Layingguide
     * @param string $layingguideId
     * @return \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($layingguideId);

    /**
     * Retrieve Layingguide matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \PavingSuperstore\Layingguide\Api\Data\LayingguideSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Layingguide
     * @param \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface $layingguide
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \PavingSuperstore\Layingguide\Api\Data\LayingguideInterface $layingguide
    );

    /**
     * Delete Layingguide by ID
     * @param string $layingguideId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($layingguideId);
}


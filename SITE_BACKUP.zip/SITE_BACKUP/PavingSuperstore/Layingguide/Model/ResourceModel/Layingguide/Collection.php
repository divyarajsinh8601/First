<?php

namespace PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide;

use PavingSuperstore\Layingguide\Model\Layingguide as JobModel;
use PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide as JobResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection {
	protected function _construct() {
		$this->_init(
			JobModel::class,
			JobResourceModel::class
		);
	}
}

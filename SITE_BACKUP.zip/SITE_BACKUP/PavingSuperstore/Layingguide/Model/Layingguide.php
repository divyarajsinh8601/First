<?php

namespace PavingSuperstore\Layingguide\Model;

use PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide as JobResourceModel;
use Magento\Framework\Model\AbstractModel;

class Layingguide extends AbstractModel {
	protected function _construct() {
		$this->_init(JobResourceModel::class);
	}
}

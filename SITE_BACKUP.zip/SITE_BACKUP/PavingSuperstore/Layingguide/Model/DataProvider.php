<?php
namespace PavingSuperstore\Layingguide\Model;

use PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide\CollectionFactory;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider {
	protected $loadedData;
	protected $collection;
	protected $_storeManager;

	public function __construct(
		$name,
		$primaryFieldName,
		$requestFieldName,
		CollectionFactory $employeeCollectionFactory,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		array $meta = [],
		array $data = []
	) {

		$this->collection = $employeeCollectionFactory->create();
		$this->_storeManager = $storeManager;
		parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
	}

	public function getData() {
		// $items = $this->collection->getItems();
		$items = $this->collection->getItems();
		if (!$items) {
			$data = $this->collection->getNewEmptyItem();
			$this->loadedData[$data->getId()] = $data->getData();
		}
		foreach ($items as $model) {
			$this->loadedData[$model->getId()] = $model->getData();
			if ($model->getImage()) {
				$m['image'][0]['name'] = $model->getImage();
				$m['image'][0]['url'] = $this->getMediaUrl() . $model->getImage();
				$fullData = $this->loadedData;
				$this->loadedData[$model->getId()] = array_merge($fullData[$model->getId()], $m);
			}
		}

		return $this->loadedData;
	}

	public function getMediaUrl() {
		$mediaUrl = $this->_storeManager->getStore()
			->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'faq/tmp/icon/';
		return $mediaUrl;
	}

}

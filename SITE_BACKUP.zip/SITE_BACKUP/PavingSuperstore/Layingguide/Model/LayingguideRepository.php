<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Layingguide\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use PavingSuperstore\Layingguide\Api\Data\LayingguideInterface;
use PavingSuperstore\Layingguide\Api\Data\LayingguideInterfaceFactory;
use PavingSuperstore\Layingguide\Api\Data\LayingguideSearchResultsInterfaceFactory;
use PavingSuperstore\Layingguide\Api\LayingguideRepositoryInterface;
use PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide as ResourceLayingguide;
use PavingSuperstore\Layingguide\Model\ResourceModel\Layingguide\CollectionFactory as LayingguideCollectionFactory;

class LayingguideRepository implements LayingguideRepositoryInterface
{

    /**
     * @var LayingguideInterfaceFactory
     */
    protected $layingguideFactory;

    /**
     * @var LayingguideCollectionFactory
     */
    protected $layingguideCollectionFactory;

    /**
     * @var Layingguide
     */
    protected $searchResultsFactory;

    /**
     * @var ResourceLayingguide
     */
    protected $resource;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;


    /**
     * @param ResourceLayingguide $resource
     * @param LayingguideInterfaceFactory $layingguideFactory
     * @param LayingguideCollectionFactory $layingguideCollectionFactory
     * @param LayingguideSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceLayingguide $resource,
        LayingguideInterfaceFactory $layingguideFactory,
        LayingguideCollectionFactory $layingguideCollectionFactory,
        LayingguideSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->layingguideFactory = $layingguideFactory;
        $this->layingguideCollectionFactory = $layingguideCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(LayingguideInterface $layingguide)
    {
        try {
            $this->resource->save($layingguide);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the layingguide: %1',
                $exception->getMessage()
            ));
        }
        return $layingguide;
    }

    /**
     * @inheritDoc
     */
    public function get($layingguideId)
    {
        $layingguide = $this->layingguideFactory->create();
        $this->resource->load($layingguide, $layingguideId);
        if (!$layingguide->getId()) {
            throw new NoSuchEntityException(__('Layingguide with id "%1" does not exist.', $layingguideId));
        }
        return $layingguide;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->layingguideCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(LayingguideInterface $layingguide)
    {
        try {
            $layingguideModel = $this->layingguideFactory->create();
            $this->resource->load($layingguideModel, $layingguide->getLayingguideId());
            $this->resource->delete($layingguideModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Layingguide: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($layingguideId)
    {
        return $this->delete($this->get($layingguideId));
    }
}

<?php

namespace PavingSuperstore\Layingguide\Controller\Adminhtml\Index;

use PavingSuperstore\Layingguide\Model\LayingguideFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Save extends \Magento\Backend\App\Action {
	protected $resultPageFactory;
	protected $layingguideFactory;
	protected $_messageManager;

	public function __construct(
		Context $context,
		PageFactory $resultPageFactory,
		LayingguideFactory $layingguideFactory,
		\Magento\Framework\Message\ManagerInterface $messageManager
	) {
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
		$this->layingguideFactory = $layingguideFactory;
		$this->_messageManager = $messageManager;
	}

	public function execute() {

		try {
			$resultPageFactory = $this->resultRedirectFactory->create();
			$data = $this->getRequest()->getPostValue();
			// $id = $data['id'];
			$model = $this->layingguideFactory->create();
			if (array_key_exists("image", $data)) {
				$imageName = $data['image'][0]['name'];
				$data['image'] = $imageName;
			} else {
				$data['image'] = '';
			}

			$model->setData($data);
			$model->save();

			$this->messageManager->addSuccessMessage(__("Data Saved Successfully."));

			if ($this->getRequest()->getparam('back') == 'save') {

				$data = $this->getRequest()->getPostValue();
				$id = $model->getId();
				return $resultPageFactory->setPath('layingguide/index/layingguide', ['id' => $id]);
			}

			if ($this->getRequest()->getparam('back') == 'close') {

				$this->_redirect('layingguide/index/layingguide');

			} else {
				$this->_messageManager->addError(__('Something is Wrong!, Please Try again'));
			}

		} catch (\Exception $e) {
			$this->_messageManager->addErrorMessage(__($e));
		}
		return $resultPageFactory->setPath('layingguide/index/layingguide');
	}
}

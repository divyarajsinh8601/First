<?php
namespace PavingSuperstore\Layingguide\Controller\Adminhtml\Index;

use PavingSuperstore\Layingguide\Model\LayingguideFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\View\Result\PageFactory;

class Delete extends Action {
	protected $resultPageFactory;
	protected $layingguideFactory;

	public function __construct(
		Context $context,
		PageFactory $resultPageFactory,
		LayingguideFactory $layingguideFactory
	) {
		$this->resultPageFactory = $resultPageFactory;
		$this->layingguideFactory = $layingguideFactory;
		parent::__construct($context);
	}

	public function execute() {
		try {
			$id = $this->getRequest()->getParam('id');
			/*print_r($id);
            exit();*/
			if ($id) {
				$model = $this->layingguideFactory->create()->load($id);
				if ($model->getData()) {
					$model->delete();
					$this->messageManager->addSuccessMessage(__("Record Delete Successfully."));
				} else {
					$this->messageManager->addError(__('Id is not valid.'));
				}

			} else {
				$this->messageManager->addError(__('Something is Wrong!, Please Try again'));
			}

		} catch (\Exception $e) {
			$this->messageManager->addErrorMessage($e, __("We can\'t delete record, Please try again."));
		}
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		$resultRedirect->setPath('layingguide/index/layingguide');
		return $resultRedirect;

	}
}

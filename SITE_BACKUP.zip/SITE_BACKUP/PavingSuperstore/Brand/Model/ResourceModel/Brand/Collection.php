<?php
declare(strict_types=1);

namespace PavingSuperstore\Brand\Model\ResourceModel\Brand;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'brand_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \PavingSuperstore\Brand\Model\Brand::class,
            \PavingSuperstore\Brand\Model\ResourceModel\Brand::class
        );
    }
}


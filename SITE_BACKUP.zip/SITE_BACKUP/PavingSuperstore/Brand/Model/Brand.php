<?php
declare(strict_types=1);

namespace PavingSuperstore\Brand\Model;

use Magento\Framework\Model\AbstractModel;
use PavingSuperstore\Brand\Api\Data\BrandInterface;

class Brand extends AbstractModel implements BrandInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\PavingSuperstore\Brand\Model\ResourceModel\Brand::class);
    }

    /**
     * @inheritDoc
     */
    public function getBrandId()
    {
        return $this->getData(self::BRAND_ID);
    }

    /**
     * @inheritDoc
     */
    public function setBrandId($brandId)
    {
        return $this->setData(self::BRAND_ID, $brandId);
    }

    /**
     * @inheritDoc
     */
    public function getBrandName()
    {
        return $this->getData(self::BRAND_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setBrandName($brandName)
    {
        return $this->setData(self::BRAND_NAME, $brandName);
    }

    /**
     * @inheritDoc
     */
    public function getBrandDescription()
    {
        return $this->getData(self::BRAND_DESCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setBrandDescription($brandDescription)
    {
        return $this->setData(self::BRAND_DESCRIPTION, $brandDescription);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedTime()
    {
        return $this->getData(self::CREATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedTime($createdTime)
    {
        return $this->setData(self::CREATED_TIME, $createdTime);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedTime()
    {
        return $this->getData(self::UPDATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedTime($updatedTime)
    {
        return $this->setData(self::UPDATED_TIME, $updatedTime);
    }
}


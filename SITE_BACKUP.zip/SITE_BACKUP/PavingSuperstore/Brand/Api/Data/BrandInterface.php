<?php
declare(strict_types=1);

namespace PavingSuperstore\Brand\Api\Data;

interface BrandInterface
{

    const BRAND_ID = 'brand_id';
    const BRAND_NAME = 'brand_name';
    const BRAND_DESCRIPTION = 'brand_description';
    const CREATED_TIME = 'created_time';
    const UPDATED_TIME = 'updated_time';

    /**
     * Get brand_id
     * @return string|null
     */
    public function getBrandId();

    /**
     * Set brand_id
     * @param string $brandId
     * @return \PavingSuperstore\Brand\Brand\Api\Data\BrandInterface
     */
    public function setBrandId($brandId);

    /**
     * Get brand_name
     * @return string|null
     */
    public function getBrandName();

    /**
     * Set brand_name
     * @param string $brandName
     * @return \PavingSuperstore\Brand\Brand\Api\Data\BrandInterface
     */
    public function setBrandName($brandName);

    /**
     * Get brand_description
     * @return string|null
     */
    public function getBrandDescription();

    /**
     * Set brand_description
     * @param string $brandDescription
     * @return \PavingSuperstore\Brand\Brand\Api\Data\BrandInterface
     */
    public function setBrandDescription($brandDescription);

    /**
     * Get created_time
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * Set created_time
     * @param string $createdTime
     * @return \PavingSuperstore\Brand\Brand\Api\Data\BrandInterface
     */
    public function setCreatedTime($createdTime);

    /**
     * Get updated_time
     * @return string|null
     */
    public function getUpdatedTime();

    /**
     * Set updated_time
     * @param string $updatedTime
     * @return \PavingSuperstore\Brand\Brand\Api\Data\BrandInterface
     */
    public function setUpdatedTime($updatedTime);
}


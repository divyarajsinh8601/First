<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Video\Model;

use Magento\Framework\Model\AbstractModel;
use PavingSuperstore\Video\Api\Data\VideoInterface;

class Video extends AbstractModel implements VideoInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\PavingSuperstore\Video\Model\ResourceModel\Video::class);
    }

    /**
     * @inheritDoc
     */
    public function getVideoId()
    {
        return $this->getData(self::VIDEO_ID);
    }

    /**
     * @inheritDoc
     */
    public function setVideoId($videoId)
    {
        return $this->setData(self::VIDEO_ID, $videoId);
    }

    /**
     * @inheritDoc
     */
    public function getVideoName()
    {
        return $this->getData(self::VIDEO_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setVideoName($videoName)
    {
        return $this->setData(self::VIDEO_NAME, $videoName);
    }

    /**
     * @inheritDoc
     */
    public function getVideoContent()
    {
        return $this->getData(self::VIDEO_CONTENT);
    }

    /**
     * @inheritDoc
     */
    public function setVideoContent($videoContent)
    {
        return $this->setData(self::VIDEO_CONTENT, $videoContent);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedTime()
    {
        return $this->getData(self::CREATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedTime($createdTime)
    {
        return $this->setData(self::CREATED_TIME, $createdTime);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedTime()
    {
        return $this->getData(self::UPDATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedTime($updatedTime)
    {
        return $this->setData(self::UPDATED_TIME, $updatedTime);
    }
}


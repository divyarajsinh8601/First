<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Video\Api\Data;

interface VideoSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Video list.
     * @return \PavingSuperstore\Video\Api\Data\VideoInterface[]
     */
    public function getItems();

    /**
     * Set video_name list.
     * @param \PavingSuperstore\Video\Api\Data\VideoInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}


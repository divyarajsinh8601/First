<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Video\Api\Data;

interface VideoInterface
{

    const UPDATED_TIME = 'updated_time';
    const CREATED_TIME = 'created_time';
    const VIDEO_CONTENT = 'video_content';
    const VIDEO_NAME = 'video_name';
    const VIDEO_ID = 'video_id';

    /**
     * Get video_id
     * @return string|null
     */
    public function getVideoId();

    /**
     * Set video_id
     * @param string $videoId
     * @return \PavingSuperstore\Video\Video\Api\Data\VideoInterface
     */
    public function setVideoId($videoId);

    /**
     * Get video_name
     * @return string|null
     */
    public function getVideoName();

    /**
     * Set video_name
     * @param string $videoName
     * @return \PavingSuperstore\Video\Video\Api\Data\VideoInterface
     */
    public function setVideoName($videoName);

    /**
     * Get video_content
     * @return string|null
     */
    public function getVideoContent();

    /**
     * Set video_content
     * @param string $videoContent
     * @return \PavingSuperstore\Video\Video\Api\Data\VideoInterface
     */
    public function setVideoContent($videoContent);

    /**
     * Get created_time
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * Set created_time
     * @param string $createdTime
     * @return \PavingSuperstore\Video\Video\Api\Data\VideoInterface
     */
    public function setCreatedTime($createdTime);

    /**
     * Get updated_time
     * @return string|null
     */
    public function getUpdatedTime();

    /**
     * Set updated_time
     * @param string $updatedTime
     * @return \PavingSuperstore\Video\Video\Api\Data\VideoInterface
     */
    public function setUpdatedTime($updatedTime);
}


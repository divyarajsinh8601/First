<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Video\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VideoRepositoryInterface
{

    /**
     * Save Video
     * @param \PavingSuperstore\Video\Api\Data\VideoInterface $video
     * @return \PavingSuperstore\Video\Api\Data\VideoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \PavingSuperstore\Video\Api\Data\VideoInterface $video
    );

    /**
     * Retrieve Video
     * @param string $videoId
     * @return \PavingSuperstore\Video\Api\Data\VideoInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($videoId);

    /**
     * Retrieve Video matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \PavingSuperstore\Video\Api\Data\VideoSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Video
     * @param \PavingSuperstore\Video\Api\Data\VideoInterface $video
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \PavingSuperstore\Video\Api\Data\VideoInterface $video
    );

    /**
     * Delete Video by ID
     * @param string $videoId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($videoId);
}


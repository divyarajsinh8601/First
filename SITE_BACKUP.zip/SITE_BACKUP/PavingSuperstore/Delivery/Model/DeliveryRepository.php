<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Delivery\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use PavingSuperstore\Delivery\Api\Data\DeliveryInterface;
use PavingSuperstore\Delivery\Api\Data\DeliveryInterfaceFactory;
use PavingSuperstore\Delivery\Api\Data\DeliverySearchResultsInterfaceFactory;
use PavingSuperstore\Delivery\Api\DeliveryRepositoryInterface;
use PavingSuperstore\Delivery\Model\ResourceModel\Delivery as ResourceDelivery;
use PavingSuperstore\Delivery\Model\ResourceModel\Delivery\CollectionFactory as DeliveryCollectionFactory;

class DeliveryRepository implements DeliveryRepositoryInterface
{

    /**
     * @var DeliveryInterfaceFactory
     */
    protected $deliveryFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var DeliveryCollectionFactory
     */
    protected $deliveryCollectionFactory;

    /**
     * @var ResourceDelivery
     */
    protected $resource;

    /**
     * @var Delivery
     */
    protected $searchResultsFactory;


    /**
     * @param ResourceDelivery $resource
     * @param DeliveryInterfaceFactory $deliveryFactory
     * @param DeliveryCollectionFactory $deliveryCollectionFactory
     * @param DeliverySearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceDelivery $resource,
        DeliveryInterfaceFactory $deliveryFactory,
        DeliveryCollectionFactory $deliveryCollectionFactory,
        DeliverySearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->deliveryFactory = $deliveryFactory;
        $this->deliveryCollectionFactory = $deliveryCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(DeliveryInterface $delivery)
    {
        try {
            $this->resource->save($delivery);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the delivery: %1',
                $exception->getMessage()
            ));
        }
        return $delivery;
    }

    /**
     * @inheritDoc
     */
    public function get($deliveryId)
    {
        $delivery = $this->deliveryFactory->create();
        $this->resource->load($delivery, $deliveryId);
        if (!$delivery->getId()) {
            throw new NoSuchEntityException(__('Delivery with id "%1" does not exist.', $deliveryId));
        }
        return $delivery;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->deliveryCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(DeliveryInterface $delivery)
    {
        try {
            $deliveryModel = $this->deliveryFactory->create();
            $this->resource->load($deliveryModel, $delivery->getDeliveryId());
            $this->resource->delete($deliveryModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Delivery: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($deliveryId)
    {
        return $this->delete($this->get($deliveryId));
    }
}


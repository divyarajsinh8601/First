<?php

namespace PavingSuperstore\Delivery\Model\Config;

class Attribute implements \Magento\Framework\Option\ArrayInterface {

    protected $eavConfig;

    public function __construct(
        \Magento\Eav\Model\Config $eavConfig
    ){
        $this->eavConfig = $eavConfig;
    }
	public function toOptionArray() {
        $attribute = $this->eavConfig->getAttribute('catalog_product', 'delivery_attr');
        $options = $attribute->getSource()->getAllOptions();
        $attribute = array();
        foreach($options as $data)
        {
            $data['value'] = $data['label'];
            $attribute[] = $data; 
        }
        return $attribute;
	}
}

<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Delivery\Model;

use Magento\Framework\Model\AbstractModel;
use PavingSuperstore\Delivery\Api\Data\DeliveryInterface;

class Delivery extends AbstractModel implements DeliveryInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\PavingSuperstore\Delivery\Model\ResourceModel\Delivery::class);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryId()
    {
        return $this->getData(self::DELIVERY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryId($deliveryId)
    {
        return $this->setData(self::DELIVERY_ID, $deliveryId);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryName()
    {
        return $this->getData(self::DELIVERY_NAME);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryName($deliveryName)
    {
        return $this->setData(self::DELIVERY_NAME, $deliveryName);
    }

    /**
     * @inheritDoc
     */
    public function getDeliveryContent()
    {
        return $this->getData(self::DELIVERY_CONTENT);
    }

    /**
     * @inheritDoc
     */
    public function setDeliveryContent($deliveryContent)
    {
        return $this->setData(self::DELIVERY_CONTENT, $deliveryContent);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedTime()
    {
        return $this->getData(self::CREATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedTime($createdTime)
    {
        return $this->setData(self::CREATED_TIME, $createdTime);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedTime()
    {
        return $this->getData(self::UPDATED_TIME);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedTime($updatedTime)
    {
        return $this->setData(self::UPDATED_TIME, $updatedTime);
    }
}


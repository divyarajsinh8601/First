<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Delivery\Api\Data;

interface DeliverySearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Delivery list.
     * @return \PavingSuperstore\Delivery\Api\Data\DeliveryInterface[]
     */
    public function getItems();

    /**
     * Set delivery_name list.
     * @param \PavingSuperstore\Delivery\Api\Data\DeliveryInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}


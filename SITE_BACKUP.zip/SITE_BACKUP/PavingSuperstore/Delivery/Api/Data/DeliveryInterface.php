<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Delivery\Api\Data;

interface DeliveryInterface
{

    const DELIVERY_ID = 'delivery_id';
    const UPDATED_TIME = 'updated_time';
    const CREATED_TIME = 'created_time';
    const DELIVERY_CONTENT = 'delivery_content';
    const DELIVERY_NAME = 'delivery_name';

    /**
     * Get delivery_id
     * @return string|null
     */
    public function getDeliveryId();

    /**
     * Set delivery_id
     * @param string $deliveryId
     * @return \PavingSuperstore\Delivery\Delivery\Api\Data\DeliveryInterface
     */
    public function setDeliveryId($deliveryId);

    /**
     * Get delivery_name
     * @return string|null
     */
    public function getDeliveryName();

    /**
     * Set delivery_name
     * @param string $deliveryName
     * @return \PavingSuperstore\Delivery\Delivery\Api\Data\DeliveryInterface
     */
    public function setDeliveryName($deliveryName);

    /**
     * Get delivery_content
     * @return string|null
     */
    public function getDeliveryContent();

    /**
     * Set delivery_content
     * @param string $deliveryContent
     * @return \PavingSuperstore\Delivery\Delivery\Api\Data\DeliveryInterface
     */
    public function setDeliveryContent($deliveryContent);

    /**
     * Get created_time
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * Set created_time
     * @param string $createdTime
     * @return \PavingSuperstore\Delivery\Delivery\Api\Data\DeliveryInterface
     */
    public function setCreatedTime($createdTime);

    /**
     * Get updated_time
     * @return string|null
     */
    public function getUpdatedTime();

    /**
     * Set updated_time
     * @param string $updatedTime
     * @return \PavingSuperstore\Delivery\Delivery\Api\Data\DeliveryInterface
     */
    public function setUpdatedTime($updatedTime);
}


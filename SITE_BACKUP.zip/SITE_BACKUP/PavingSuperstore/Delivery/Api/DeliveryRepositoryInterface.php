<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace PavingSuperstore\Delivery\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DeliveryRepositoryInterface
{

    /**
     * Save Delivery
     * @param \PavingSuperstore\Delivery\Api\Data\DeliveryInterface $delivery
     * @return \PavingSuperstore\Delivery\Api\Data\DeliveryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \PavingSuperstore\Delivery\Api\Data\DeliveryInterface $delivery
    );

    /**
     * Retrieve Delivery
     * @param string $deliveryId
     * @return \PavingSuperstore\Delivery\Api\Data\DeliveryInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($deliveryId);

    /**
     * Retrieve Delivery matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \PavingSuperstore\Delivery\Api\Data\DeliverySearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Delivery
     * @param \PavingSuperstore\Delivery\Api\Data\DeliveryInterface $delivery
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \PavingSuperstore\Delivery\Api\Data\DeliveryInterface $delivery
    );

    /**
     * Delete Delivery by ID
     * @param string $deliveryId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($deliveryId);
}


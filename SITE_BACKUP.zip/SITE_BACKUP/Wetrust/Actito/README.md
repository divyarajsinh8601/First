# Actito module for Magento 2
@todo
## Table of Contents
- [Installation](#installation)
- [Usage](#usage)
- [Support](#support)
- [Contributing](#contributing)
## Installation
```sh
composer install wetrust/actito
```
## Usage
@todo
## Support
Please [open an issue](https://github.com/we-trust/m2-module-actito/issues/new) for support.
## Contributing
Please contribute using [Github Flow](https://guides.github.com/introduction/flow/). Create a branch, add commits, and [open a pull request](https://github.com/we-trust/m2-module-actito/compare).

<?php declare(strict_types=1);
namespace Wetrust\Actito\Console\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Wetrust\Actito\Api\Data\TaskInterface;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Exception\ProcessException;
use Wetrust\Actito\Helper\Data;
use Wetrust\Actito\Model\FlowFactory;
use Wetrust\Actito\Model\ResourceModel\Task;
use Wetrust\Actito\Model\TaskFactory;

class Process extends Command
{
    /**
     * @var Data
     */
    protected $helper;
    /**
     * @var TaskFactory
     */
    protected $taskFactory;
    /**
     * @var Task
     */
    protected $taskResource;
    /**
     * @var FlowFactory
     */
    protected $flowFactory;
    /**
     * @var TaskRepositoryInterface
     */
    private $taskRepository;
    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    private $searchCriteriaBuilder;

    private $appState;

    /**
     * Process constructor.
     * @param TaskFactory $taskFactory
     * @param Task $taskResource
     * @param Data $helper
     * @param FlowFactory $flowFactory
     * @param TaskRepositoryInterface $taskRepository
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     */
    public function __construct(
        TaskFactory $taskFactory,
        Task $taskResource,
        Data $helper,
        FlowFactory $flowFactory,
        TaskRepositoryInterface $taskRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\App\State $appState,
        string $name = null
    ) {
        $this->helper = $helper;
        $this->taskFactory = $taskFactory;
        $this->taskResource = $taskResource;
        $this->flowFactory = $flowFactory;
        $this->taskRepository = $taskRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->appState = $appState;
        parent::__construct($name);
    }

    protected function configure()
    {
        $this->setName('actito:process')
            ->setDescription('Process pending tasks');

        $this->setDefinition(
            [
                new InputArgument(
                    'id',
                    InputArgument::OPTIONAL,
                    'ID'
                )
            ]
        );

        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return void
     */
    protected function execute(InputInterface $input, OutputInterface $output): void
    {
        echo 'Starting' . "\n";
        $this->appState->setAreaCode(\Magento\Framework\App\Area::AREA_GLOBAL);
        if (! $this->helper->isEnabled()) {
            echo 'Actito is not Enabled' . "\n";
            return;
        }

        try {
            $this->searchCriteriaBuilder
                ->addFilter('job_id', ['in' => explode(',', $input->getArgument('id'))]);
            $tasks = $this->taskRepository->getList($this->searchCriteriaBuilder->create());
            /** @var TaskInterface $task */
            foreach ($tasks->getItems() as $task) {
                $this->flowFactory
                    ->setFlowId($task->getFlowId())
                    ->setDirection($task->getDirection())
                    ->process($task);
            }
        } catch (ProcessException $e) {
            echo 'Cron Actito Magento: ' . $e->getMessage() . "\n";
            $this->helper->log('Cron Actito Magento: ' . $e->getMessage(), 'error');
        } catch (\Zend_Mail_Exception $e) {
            $this->helper->log($e->getMessage(), 'error');
        }
    }
}

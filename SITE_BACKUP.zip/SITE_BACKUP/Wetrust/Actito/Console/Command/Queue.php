<?php declare(strict_types=1);

namespace Wetrust\Actito\Console\Command;

use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\ResourceModel\Order;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Wetrust\Actito\Model\ResourceModel\Task as TaskResource;
use Wetrust\Actito\Model\TaskFactory;

class Queue extends Command
{
    /**
     * @var TaskFactory
     */
    protected $taskFactory;
    /**
     * @var TaskResource
     */
    protected $taskResource;
    /**
     * @var OrderFactory
     */
    protected $orderFactory;
    /**
     * @var Order
     */
    protected $orderResource;

    /**
     * Queue constructor.
     * @param string|null $name
     * @param TaskFactory $taskFactory
     * @param TaskResource $taskResource
     * @param OrderFactory $orderFactory
     * @param Order $orderResource
     */
    public function __construct(
        TaskFactory $taskFactory,
        TaskResource $taskResource,
        OrderFactory $orderFactory,
        Order $orderResource,
        string $name = null
    )
    {
        $this->taskFactory = $taskFactory;
        $this->taskResource = $taskResource;
        $this->orderFactory = $orderFactory;
        $this->orderResource = $orderResource;

        parent::__construct($name);
    }

    protected function configure()
    {
        $this->setName('actito:queue')
            ->setDescription('Queue Task');

        $this->setDefinition(
            [
                new InputArgument(
                    'id',
                    InputArgument::REQUIRED,
                    'ID'
                ),
                new InputOption(
                    'flow-id',
                    'i',
                    InputOption::VALUE_REQUIRED,
                    'Flow ID'
                ),
                new InputOption(
                    'direction',
                    'd',
                    InputOption::VALUE_OPTIONAL,
                    'Direction'
                )
            ]
        );

        parent::configure();
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     * @return int|void
     * @throws \Exception
     */
    protected function execute(InputInterface $input, OutputInterface $output): void
    {
        $ids = explode(',', $input->getArgument('id'));
        foreach ($ids as $id) {
            $task = $this->taskFactory->create();
            try {
                $task->enqueue(
                    $input->getOption('flow-id'),
                    $input->getOption('direction'),
                    $id,
                    "",
                    'manual');
            } catch (AlreadyExistsException $e) {
                die($e->getMessage());
            }
        }
    }
}

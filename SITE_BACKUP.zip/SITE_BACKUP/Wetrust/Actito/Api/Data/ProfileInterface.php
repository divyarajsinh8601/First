<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface ProfileInterface
{
    const EMAIL = 'email';
    const CUSTOMER_ID = 'customer_id';
    const PHONE_NUMBER = 'phone_number';
    const STORE_ID = 'store_id';
    const LASTNAME = 'lastname';
    const MIDDLENAME = 'middlename';
    const ORIGIN = 'origin';
    const DOB = 'dob';
    const CIVILITY = 'civility';
    const ENTITY_ID = 'entity_id';
    const ACTITO_SYNC = 'actito_sync';
    const FIRSTNAME = 'firstname';
    const COUNTRY_ID = 'country_id';
    const SUBSCRIBER_ID = 'subscriber_id';

    /**
     * Get entity_id
     * @return string|null
     */
    public function getEntityId();

    /**
     * Set entity_id
     * @param string $entityId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setEntityId($entityId);

    /**
     * Get customer_id
     * @return string|null
     */
    public function getCustomerId();

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get subscriber_id
     * @return string|null
     */
    public function getSubscriberId();

    /**
     * Set subscriber_id
     * @param string $subscriberId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setSubscriberId($subscriberId);

    /**
     * Get store_id
     * @return string|null
     */
    public function getStoreId();

    /**
     * Set store_id
     * @param string $storeId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setStoreId($storeId);

    /**
     * Get email
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     * @param string $email
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setEmail($email);

    /**
     * Get firstname
     * @return string|null
     */
    public function getFirstname();

    /**
     * Set firstname
     * @param string $firstname
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setFirstname($firstname);

    /**
     * Get middlename
     * @return string|null
     */
    public function getMiddlename();

    /**
     * Set middlename
     * @param string $middlename
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setMiddlename($middlename);

    /**
     * Get lastname
     * @return string|null
     */
    public function getLastname();

    /**
     * Set lastname
     * @param string $lastname
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setLastname($lastname);

    /**
     * Get civility
     * @return string|null
     */
    public function getCivility();

    /**
     * Set civility
     * @param string $civility
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setCivility($civility);

    /**
     * Get phone_number
     * @return string|null
     */
    public function getPhoneNumber();

    /**
     * Set phone_number
     * @param string $phoneNumber
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setPhoneNumber($phoneNumber);

    /**
     * Get country_id
     * @return string|null
     */
    public function getCountryId();

    /**
     * Set country_id
     * @param string $countryId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setCountryId($countryId);

    /**
     * Get dob
     * @return string|null
     */
    public function getDob();

    /**
     * Set dob
     * @param string $dob
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setDob($dob);

    /**
     * Get actito_sync
     * @return string|null
     */
    public function getActitoSync();

    /**
     * Set actito_sync
     * @param string $actitoSync
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setActitoSync($actitoSync);

    /**
     * Get origin
     * @return string|null
     */
    public function getOrigin();

    /**
     * Set origin
     * @param string $origin
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     */
    public function setOrigin($origin);
}


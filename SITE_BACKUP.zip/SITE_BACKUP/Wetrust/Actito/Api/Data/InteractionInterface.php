<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface InteractionInterface
{
    const ENTITY_ID = 'entity_id';
    const PROFILE_ID = 'profile_id';
    const PROFILE_SUBSCRIPTION_ID = 'profile_subscription_id';
    const POSITION = 'position';
    const ORIGIN = 'origin';    
    const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';

    /**
     * Get entity_id
     * @return string|null
     */
    public function getentityId();

    /**
     * Set entity_id
     * @param string $entityId
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setentityId($entityId);

    /**
     * Get profile_id
     * @return string|null
     */
    public function getProfileId();

    /**
     * Set profile_id
     * @param string $profileId
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setProfileId($profileId);

    /**
     * Get profile_subscription_id
     * @return string|null
     */
    public function getProfileSubscriptionId();

    /**
     * Set profile_subscription_id
     * @param string $profileSubscriptionId
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setProfileSubscriptionId($profileSubscriptionId);

    /**
     * Get origin
     * @return string|null
     */
    public function getOrigin();

    /**
     * Set origin
     * @param string $origin
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setOrigin($origin);

    /**
     * Get position
     * @return string|null
     */
    public function getPosition();

    /**
     * Set position
     * @param string $position
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setPosition($position);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Wetrust\Actito\Interaction\Api\Data\InteractionInterface
     */
    public function setUpdatedAt($updatedAt);
}
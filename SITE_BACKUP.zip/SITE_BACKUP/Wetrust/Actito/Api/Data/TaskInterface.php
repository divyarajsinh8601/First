<?php declare(strict_types=1);
namespace Wetrust\Actito\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface TaskInterface extends ExtensibleDataInterface
{
    const STATUS_PENDING = 'pending';
    const STATUS_ERROR = 'error';
    const STATUS_SUCCESS = 'success';
    const STATUS_PROCESSING = 'process';

    public function getFlowId(): string;

    public function setFlowId(string $flowId): TaskInterface;

    public function getDirection(): string;

    public function setDirection(string $direction): TaskInterface;

    public function getObjType(): string;

    public function setObjType(string $objType): TaskInterface;

    public function getObjId(): string;

    public function setObjId(string $objId): TaskInterface;

    public function getRetryCount(): int;

    public function setRetryCount(int $retryCount): TaskInterface;

    public function getStatus(): string;

    public function setStatus(string $status): TaskInterface;

    public function getMessages(): string;

    public function setMessages(string $messages): TaskInterface;

    public function getCreatedAt(): string;

    public function setCreatedAt(string $createdAt): TaskInterface;

    public function getLastStartAt(): string;

    public function setLastStartAt(string $lastStartAt): TaskInterface;

    public function getCompletedAt(): string;

    public function setCompletedAt(string $completedAt): TaskInterface;

    public function increaseRetryCount(): TaskInterface;

    public function addRequest($request): TaskInterface;

    public function addMessage($message): TaskInterface;

    public function success($successMessage): TaskInterface;

    public function error($errorMessage): TaskInterface;
}

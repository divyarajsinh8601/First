<?php declare(strict_types=1);
namespace Wetrust\Actito\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface TaskSearchResultsInterface extends SearchResultsInterface
{
    /**
     * @return TaskInterface[]
     */
    public function getItems(): array;

    /**
     * @param TaskInterface[] $items
     * @return void
     */
    public function setItems(array $items);
}

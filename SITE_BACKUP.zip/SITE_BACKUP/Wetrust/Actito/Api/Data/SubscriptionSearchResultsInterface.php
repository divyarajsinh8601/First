<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface SubscriptionSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Subscription list.
     * @return \Wetrust\Actito\Api\Data\SubscriptionInterface[]
     */
    public function getItems();

    /**
     * Set profile_id list.
     * @param \Wetrust\Actito\Api\Data\SubscriptionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface ProfileSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Profile list.
     * @return \Wetrust\Actito\Api\Data\ProfileInterface[]
     */
    public function getItems();

    /**
     * Set customer_id list.
     * @param \Wetrust\Actito\Api\Data\ProfileInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}


<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface SubscriptionInterface
{
    const PROFILE_ID = 'profile_id';
    const ENTITY_ID = 'entity_id';
    const VALUE = 'value';    
    const CODE = 'code';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';

    /**
     * Get entity_id
     * @return string|null
     */
    public function getEntityId();

    /**
     * Set entity_id
     * @param string $entityId
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setEntityId($entityId);

    /**
     * Get profile_id
     * @return string|null
     */
    public function getProfileId();

    /**
     * Set profile_id
     * @param string $profileId
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setProfileId($profileId);

    /**
     * Get code
     * @return string|null
     */
    public function getCode();

    /**
     * Set code
     * @param string $code
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setCode($code);

    /**
     * Get value
     * @return string|null
     */
    public function getValue();

    /**
     * Set value
     * @param string $value
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setValue($value);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Wetrust\Actito\Subscription\Api\Data\SubscriptionInterface
     */
    public function setUpdatedAt($updatedAt);
}
<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api\Data;

interface InteractionSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Interaction list.
     * @return \Wetrust\Actito\Api\Data\InteractionInterface[]
     */
    public function getItems();

    /**
     * Set profile_id list.
     * @param \Wetrust\Actito\Api\Data\InteractionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
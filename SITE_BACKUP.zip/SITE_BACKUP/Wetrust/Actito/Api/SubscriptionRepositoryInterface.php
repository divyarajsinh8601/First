<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProfileSubscriptionRepositoryInterface
{

    /**
     * Save Subscription
     * @param \Wetrust\Actito\Api\Data\SubscriptionInterface $subscription
     * @return \Wetrust\Actito\Api\Data\SubscriptionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Wetrust\Actito\Api\Data\SubscriptionInterface $subscription
    );

    /**
     * Retrieve Subscription
     * @param string $entityId
     * @return \Wetrust\Actito\Api\Data\SubscriptionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($entityId);

    /**
     * Retrieve Subscription matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Wetrust\Actito\Api\Data\SubscriptionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Subscription
     * @param \Wetrust\Actito\Api\Data\SubscriptionInterface $subscription
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Wetrust\Actito\Api\Data\SubscriptionInterface $subscription
    );

    /**
     * Delete Subscription by ID
     * @param string $subscriptionId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($subscriptionId);
}

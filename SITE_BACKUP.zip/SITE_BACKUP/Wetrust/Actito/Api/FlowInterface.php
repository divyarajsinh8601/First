<?php declare(strict_types=1);
namespace Wetrust\Actito\Api;

use Wetrust\Actito\Api\Data\TaskInterface as Task;

interface FlowInterface
{
    /**
     * Launch process for Task
     *
     * @param Task $task
     */
    public function launchProcess(Task $task): void;
}

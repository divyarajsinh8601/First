<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProfileRepositoryInterface
{

    /**
     * Save Profile
     * @param \Wetrust\Actito\Api\Data\ProfileInterface $profile
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Wetrust\Actito\Api\Data\ProfileInterface $profile
    );

    /**
     * Retrieve Profile
     * @param string $profileId
     * @return \Wetrust\Actito\Api\Data\ProfileInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($profileId);

    /**
     * Retrieve Profile matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Wetrust\Actito\Api\Data\ProfileSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Profile
     * @param \Wetrust\Actito\Api\Data\ProfileInterface $profile
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Wetrust\Actito\Api\Data\ProfileInterface $profile
    );

    /**
     * Delete Profile by ID
     * @param string $profileId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($profileId);
}


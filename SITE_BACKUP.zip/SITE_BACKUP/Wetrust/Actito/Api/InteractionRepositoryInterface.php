<?php
declare(strict_types=1);

namespace Wetrust\Actito\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface InteractionRepositoryInterface
{

    /**
     * Save Interaction
     * @param \Wetrust\Actito\Api\Data\InteractionInterface $interaction
     * @return \Wetrust\Actito\Api\Data\InteractionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Wetrust\Actito\Api\Data\InteractionInterface $interaction
    );

    /**
     * Retrieve Interaction
     * @param string $interactionId
     * @return \Wetrust\Actito\Api\Data\InteractionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($interactionId);

    /**
     * Retrieve Interaction matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Wetrust\Actito\Api\Data\InteractionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Interaction
     * @param \Wetrust\Actito\Api\Data\InteractionInterface $interaction
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Wetrust\Actito\Api\Data\InteractionInterface $interaction
    );

    /**
     * Delete Interaction by ID
     * @param string $interactionId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($interactionId);
}
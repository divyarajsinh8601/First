<?php declare(strict_types=1);
namespace Wetrust\Actito\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResults;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Wetrust\Actito\Api\Data\TaskInterface;

interface TaskRepositoryInterface
{
    /**
     * @param TaskInterface $task
     * @return TaskInterface
     * @throws AlreadyExistsException
     */
    public function save(TaskInterface $task): TaskInterface;

    /**
     * @param $taskId
     * @return TaskInterface
     * @throws NoSuchEntityException
     */
    public function getById($taskId): TaskInterface;

    /**
     * @param TaskInterface $task
     * @return bool
     * @throws CouldNotDeleteException
     */
    public function delete(TaskInterface $task): bool;

    /**
     * @param $taskId
     * @return bool
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($taskId): bool;

    /**
     * @param $value
     * @param null $attributeCode
     * @return mixed
     * @throws NoSuchEntityException
     */
    public function get($value, $attributeCode = null): TaskInterface;

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return SearchResults
     */
    public function getList(SearchCriteriaInterface $searchCriteria): SearchResults;
}

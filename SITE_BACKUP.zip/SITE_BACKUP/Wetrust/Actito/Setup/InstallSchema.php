<?php declare(strict_types=1);

namespace Wetrust\Actito\Setup;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $table = $setup->getConnection()
            ->newTable($setup->getTable('actito_task'))
            ->addColumn(
                'job_id',
                Table::TYPE_INTEGER,
                null,
                [
                    'identity' => true,
                    'unsigned' => true,
                    'nullable' => false,
                    'primary' => true
                ],
                'Job ID'
            )
            ->addColumn(
                'flow_id',
                Table::TYPE_TEXT,
                25,
                [
                    'nullable' => true,
                ],
                'Flow'
            )
            ->addColumn(
                'direction',
                Table::TYPE_TEXT,
                6,
                [
                    'nullable' => true,
                ],
                'Direction'
            )
            ->addColumn(
                'obj_id',
                Table::TYPE_TEXT,
                50,
                [
                    'nullable' => false,
                ],
                'Flow'
            )
            ->addColumn(
                'request',
                Table::TYPE_TEXT,
                null,
                [
                    'nullable' => true,
                ],
                'Request Data'
            )
            ->addColumn(
                'retry_count',
                Table::TYPE_SMALLINT,
                null,
                [
                    'nullable' => false,
                    'default' => 0
                ],
                'Retry count'
            )
            ->addColumn(
                'status',
                Table::TYPE_TEXT,
                7,
                [
                    'nullable' => false,
                    'default' => 'pending'
                ],
                'Status'
            )
            ->addColumn(
                'messages',
                Table::TYPE_TEXT,
                null,
                [
                    'nullable' => true,
                ],
                'Messages'
            )
            ->addColumn(
                'created_at',
                Table::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => false,
                    'default' => Table::TIMESTAMP_INIT
                ],
                'Created At'
            )
            ->addColumn(
                'last_start_at',
                Table::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => true,
                ],
                'Last started at'
            )
            ->addColumn(
                'completed_at',
                Table::TYPE_TIMESTAMP,
                null,
                [
                    'nullable' => true,
                ],
                'Completed at'
            )
            ->addIndex(
                $setup->getIdxName(
                    $setup->getTable('actito_task'),
                    [
                        'flow_id',
                        'direction',
                        'obj_id'
                    ],
                    \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ),
                [
                    'flow_id',
                    'direction',
                    'obj_id'
                ],
                [
                    'type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_UNIQUE
                ]
            );

        $setup->getConnection()->createTable($table);

        $customerTable = $setup->getTable('customer_entity');

        $setup->getConnection()->addColumn(
            $customerTable,
            'actito_created',
            [
                'type' => Table::TYPE_SMALLINT,
                'nullable' => false,
                'default' => 0,
                'comment' => "Actito id created"
            ]
        );

        $setup->endSetup();
    }
}
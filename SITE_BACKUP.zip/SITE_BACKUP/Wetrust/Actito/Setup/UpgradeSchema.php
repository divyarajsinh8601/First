<?php declare(strict_types=1);

namespace Wetrust\Actito\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->addActitoSentColumnToQuoteTable($setup);
    }

    private function addActitoSentColumnToQuoteTable(SchemaSetupInterface $setup)
    {
        $tableName = $setup->getTable('quote');
        $columnName = 'actito_created';
        $connection = $setup->getConnection();

        if ($connection->isTableExists($tableName)) {
            $connection = $setup->getConnection();
            if (! $connection->tableColumnExists($tableName, $columnName)) {
                $connection->addColumn(
                    $setup->getTable('quote'),
                    $columnName,
                    [
                        'type' => Table::TYPE_BOOLEAN,
                        'default' => '0',
                        'nullable' => false,
                        'comment' => '..'
                    ]
                );
            }
        }
    }
}
<?php declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;
use Wetrust\Actito\Api\Data\TaskInterface;

class Task extends AbstractModel implements IdentityInterface, TaskInterface
{
    const CACHE_TAG = 'Wetrust_actito_task';

    protected $_cacheTag = self::CACHE_TAG;

    protected $_eventPrefix = self::CACHE_TAG;

    protected function _construct()
    {
        $this->_init('Wetrust\Actito\Model\ResourceModel\Task');
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * Increase retry_count by 1
     *
     * @return $this
     */
    public function increaseRetryCount(): TaskInterface
    {
        $this->setData('retry_count', $this->getData('retry_count') + 1);

        return $this;
    }

    public function addRequest($request): TaskInterface
    {
        $this->setData('request', $request);

        $this->getResource()->save($this);

        return $this;
    }

    public function addMessage($message): TaskInterface
    {
        $this->setData('messages', $message);

        $this->getResource()->save($this);

        return $this;
    }

    public function getFlowId(): string
    {
        return $this->_getData('flow_id');
    }

    public function setFlowId(string $flowId): TaskInterface
    {
        $this->setData('flow_id', $flowId);

        return $this;
    }

    public function getDirection(): string
    {
        return $this->_getData('direction');
    }

    public function setDirection(string $direction): TaskInterface
    {
        $this->setData('direction', $direction);

        return $this;
    }

    public function getObjType(): string
    {
        return $this->_getData('obj_type');
    }

    public function setObjType(string $objType): TaskInterface
    {
        $this->setData('obj_type', $objType);

        return $this;
    }

    public function getObjId(): string
    {
        return $this->_getData('obj_id');
    }

    public function setObjId(string $objId): TaskInterface
    {
        $this->setData('obj_id', $objId);

        return $this;
    }

    public function getRetryCount(): int
    {
        return (int)$this->_getData('retry_count');
    }

    public function setRetryCount(int $retryCount): TaskInterface
    {
        $this->setData('retry_count', $retryCount);

        return $this;
    }

    public function getStatus(): string
    {
        return $this->_getData('status');
    }

    public function setStatus(string $status): TaskInterface
    {
        $this->setData('status', $status);

        return $this;
    }

    public function getMessages(): string
    {
        return $this->_getData('messages');
    }

    public function setMessages(string $messages): TaskInterface
    {
        $this->setData('messages', $messages);

        return $this;
    }

    public function getCreatedAt(): string
    {
        return $this->_getData('created_at');
    }

    public function setCreatedAt(string $createdAt): TaskInterface
    {
        $this->setData('created_at', $createdAt);

        return $this;
    }

    public function getLastStartAt(): string
    {
        return $this->_getData('last_start_at');
    }

    public function setLastStartAt(string $lastStartAt): TaskInterface
    {
        $this->setData('last_start_at', $lastStartAt);

        return $this;
    }

    public function getCompletedAt(): string
    {
        return $this->_getData('completed_at');
    }

    public function setCompletedAt(string $completedAt): TaskInterface
    {
        $this->setData('completed_at', $completedAt);

        return $this;
    }

    public function process(): TaskInterface
    {
        $this->setData('status', TaskInterface::STATUS_PROCESSING);

        $this->getResource()->save($this);

        return $this;
    }

    public function success($successMessage): TaskInterface
    {
        $this->setData('status', TaskInterface::STATUS_SUCCESS)
            ->setData('messages', $successMessage);

        $this->getResource()->save($this);

        return $this;
    }

    public function error($errorMessage): TaskInterface
    {
        $this->setData('status', TaskInterface::STATUS_ERROR)
            ->setData('messages', $errorMessage);

        $this->getResource()->save($this);

        return $this;
    }

    public function reset($save = true): TaskInterface
    {
        $this
            ->setData('retry_count', 0)
            ->setData('last_start_at', null)
            ->setData('completed_at', null)
            ->setData('messages', null)
            ->setData('status', TaskInterface::STATUS_PENDING)
            ->setData('request', '');
        if($save) {
            $this->getResource()->save($this);
        }

        return $this;
    }

    /**
     * @param $idFlux
     * @param $direction
     * @param $objId
     * @param $xmlData
     * @param string $type
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    public function enqueue($idFlux, $direction, $objId, $xmlData = "", $type = 'auto')
    {
        $taskCollection = $this->getResourceCollection();
        $taskCollection
            ->addFieldToFilter('flow_id', $idFlux)
            ->addFieldToFilter('direction', $direction)
            ->addFieldToFilter('obj_id', $objId);

        if ($jobId = $taskCollection->getFirstItem()->getId()) {
            $this->load($jobId);
        }

        $this
            ->reset(false)
            ->setData('request', $xmlData)
            ->setData('flow_id', $idFlux)
            ->setData('direction', $direction)
            ->setData('type', $type)
            ->setData('obj_id', $objId);

        $this->getResource()->save($this);
    }

}

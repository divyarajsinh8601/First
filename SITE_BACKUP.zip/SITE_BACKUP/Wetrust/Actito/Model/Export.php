<?php declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;

class Export
{
    /**
     * @var DateTimeFactory
     */
    private $dateTimeFactory;

    /**
     * @var ProductCollectionFactory
     */
    private $productCollectionFactory;

    /**
     * @var null
     */
    protected $customId = null;

    /**
     * @var ActitoHelper
     */
    protected $helper;

    /**
     * @var Connector
     */
    protected $connector;

    /**
     * @var EventManager
     */
    protected $eventManager;

    /**
     * @var EmulationFactory
     */
    protected $emulationFactory;

    /**
     * Export constructor.
     * @param DateTimeFactory $dateTimeFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param ActitoHelper $helper
     * @param Connector $connector
     */
    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager
    ) {
        $this->dateTimeFactory = $dateTimeFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->helper = $helper;
        $this->connector = $connector;
        $this->emulationFactory = $emulationFactory;
        $this->storeManager = $storeManager;
        $this->eventManager = $eventManager;
    }

    /**
     * @return array
     */
    public function getIntervalDates(): array
    {
        $dateTime = $this->dateTimeFactory->create();
        $startDate = $dateTime->date('yyyy-MM-dd HH:mm:ss', strtotime('-' . $this::INTERVAL_MINUTES . ' minute'));
        $endDate = $dateTime->date('yyyy-MM-dd HH:mm:ss');

        return [
            'begin' => $startDate,
            'end' => $endDate
        ];
    }

    /**
     * @param array $productIds
     * @param string $attr
     * @return array
     */
    public function getProductData($productIds = [], $attr = 'entity_id'): array
    {
        $productData = [];

        $productCollection = $this->productCollectionFactory->create();
        $productCollection
            ->addAttributeToFilter($attr, ['in' => $productIds])
            ->addAttributeToSelect([
                'image',
                'small_image',
                'thumbnail',
                'name',
                'sku'
            ]);
        
        $this->eventManager->dispatch('actito_product_data', [
            'productCollection' => $productCollection
        ]);

        $productCollection
            ->addUrlRewrite()
            ->addPriceData()
            ->addMinimalPrice()
            ->addFinalPrice()
            ->addTaxPercents();

        foreach ($productCollection as $product) {
            $productData[$product->getData($attr)] = $product;
        }

        return $productData;
    }

    /**
     * @param $info
     * @return array
     */
    public function formatProperties($info): array
    {
        $data = [];
        $data['businessKey'] = $info['businessKey'];
        foreach ($info['properties'] as $attribute) {
            $data[$attribute['name']] = $attribute['value'];
        }

        return $data;
    }
}

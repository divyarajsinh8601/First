<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\Quote;

use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Flow;
use Wetrust\Actito\Model\Export\Quote as ExportQuote;


class Export extends Flow
{
    const FLOW_ID = 'QUOTE';
    /**
     * @var ExportQuote
     */
    private $exportQuote;

    private $quoteFactory;

    private $quoteResource;

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Quote\Model\ResourceModel\Quote $quoteResource,
        ExportQuote $exportQuote
    ) {

        $this->exportQuote = $exportQuote;
        $this->quoteFactory = $quoteFactory;
        $this->quoteResource = $quoteResource;
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        $this->exportQuote->process($task);
    }
}

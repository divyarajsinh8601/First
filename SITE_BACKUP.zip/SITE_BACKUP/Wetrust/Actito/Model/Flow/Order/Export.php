<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\Order;

use Magento\Customer\Model\CustomerFactory;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Flow;

class Export extends Flow
{
    const FLOW_ID = 'ORDER';

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository
    ) {
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        die('NOT YET IMPLEMENTED');
    }
}

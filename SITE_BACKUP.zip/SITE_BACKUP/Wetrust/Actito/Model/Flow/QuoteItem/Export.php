<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\QuoteItem;

use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export\QuoteItem as ExportQuoteItem;
use Wetrust\Actito\Model\Flow;

class Export extends Flow
{
    const FLOW_ID = 'QUOTE_ITEM';
    /**
     * @var ExportQuoteItem
     */
    private $exportQuoteItem;

    private $quoteFactory;

    private $quoteResource;

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     * @param ExportQuoteItem $exportQuoteItem
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Quote\Model\ResourceModel\Quote $quoteResource,
        ExportQuoteItem $exportQuoteItem
    ) {
        $this->exportQuoteItem = $exportQuoteItem;
        $this->quoteFactory = $quoteFactory;
        $this->quoteResource = $quoteResource;
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        $this->exportQuoteItem->process($task);
    }
}

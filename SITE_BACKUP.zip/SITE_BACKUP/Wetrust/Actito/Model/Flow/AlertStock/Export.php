<?php

namespace Wetrust\Actito\Model\Flow\AlertStock;

use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Flow;
use Wetrust\Actito\Model\Export\AlertStock as ExportAlertStock;

class Export extends Flow
{

    const FLOW_ID = 'ALERT_STOCK';
    
    /**
     * @var ExportAlertStock
     */
    private $exportAlertStock;


    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     * @param ExportAlertStock $exportAlertStock
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        ExportAlertStock $exportAlertStock
    ) {

        $this->exportAlertStock = $exportAlertStock;
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        $this->exportAlertStock->process($task);
    }

}

<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\Customer;

use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\ResourceModel\Customer as CustomerResource;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export\Customer as ExportCustomer;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Model\Flow;

class Export extends Flow
{
    const FLOW_ID = 'CUSTOMER';
    /**
     * @var ExportCustomer
     */
    private $exportCustomer;
    /**
     * @var CustomerFactory
     */
    private $customerFactory;
    /**
     * @var CustomerResource
     */
    private $customerResource;

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     * @param ExportCustomer $exportCustomer
     * @param CustomerFactory $customerFactory
     * @param CustomerResource $customerResource
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        ExportCustomer $exportCustomer,
        CustomerFactory $customerFactory,
        CustomerResource $customerResource
    ) {
        $this->exportCustomer = $exportCustomer;
        $this->customerFactory = $customerFactory;
        $this->customerResource = $customerResource;
        parent::__construct($helper, $taskRepository);
    }

    protected function processSuccess(Task $task): void
    {
        $customer = $this->customerFactory->create();
        $this->customerResource->load($customer, $task->getObjId());

        $customer->setData('actito_created', 1);
        $this->customerResource->save($customer);

        parent::processSuccess($task);
    }

    protected function process(Task $task): void
    {
        $this->exportCustomer->process($task);
    }
}

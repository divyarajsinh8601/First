<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\OrderItem;

use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\ResourceModel\Customer as CustomerResource;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export\OrderItem as ExportOrderItem;
use Wetrust\Actito\Model\Flow;

class Export extends Flow
{
    const FLOW_ID = 'ORDER_ITEM';
    /**
     * @var ExportOrderItem
     */
    private $exportOrderItem;

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     * @param ExportOrderItem $exportOrderItem
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        ExportOrderItem $exportOrderItem
    ) {
        $this->exportOrderItem = $exportOrderItem;
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        $this->exportOrderItem->process($task);
    }
}

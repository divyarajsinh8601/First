<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Flow\NewsletterSubscriber;

use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\ResourceModel\Customer as CustomerResource;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export\NewsletterSubscriber;
use Wetrust\Actito\Model\Flow;

class Export extends Flow
{
    const FLOW_ID = 'NEWSLETTER_SUBSCRIBER';
    /**
     * @var NewsletterSubscriber
     */
    private $newsletterSubscriber;

    /**
     * Export constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     * @param ExportOrderItem $exportOrderItem
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository,
        NewsletterSubscriber $newsletterSubscriber
    ) {
        $this->newsletterSubscriber = $newsletterSubscriber;
        parent::__construct($helper, $taskRepository);
    }

    protected function process(Task $task): void
    {
        $this->newsletterSubscriber->process($task);
    }
}

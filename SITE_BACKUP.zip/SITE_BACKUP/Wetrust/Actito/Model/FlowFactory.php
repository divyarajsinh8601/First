<?php declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Magento\Framework\ObjectManagerInterface;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\FlowInterface;
use Wetrust\Actito\Exception\ProcessException;

class FlowFactory
{
    protected $flowId;
    protected $direction;

    /**
     * @var ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * FlowFactory constructor.
     * @param ObjectManagerInterface $objectManager
     */
    public function __construct(ObjectManagerInterface $objectManager)
    {
        $this->objectManager = $objectManager;
    }

    /**
     * @param $flowId
     * @return $this
     */
    public function setFlowId($flowId): FlowFactory
    {
        $this->flowId = $flowId;

        return $this;
    }

    /**
     * @param $direction
     * @return $this
     */
    public function setDirection($direction): FlowFactory
    {
        $this->direction = $direction;

        return $this;
    }

    /**
     * @param Task $task
     * @throws ProcessException
     */
    public function process(Task $task)
    {
        if ((null === $this->flowId) || (null === $this->direction)) {
            throw new ProcessException('Cannot process task');
        }

        $task->process();

        $processor = $this->getProcessor($this->flowId, $this->direction);
        $processor->launchProcess($task);
    }

    /**
     * @param $flowId
     * @param $direction
     * @return FlowInterface
     * @throws ProcessException
     */
    protected function getProcessor($flowId, $direction): FlowInterface
    {
        $flowIdClassName = ucfirst(strtolower($flowId));
        $directionClassName = ucfirst(strtolower($direction));

        $flowIdClassNameParts = explode('_', $flowIdClassName);
        $flowIdClassName = '';
        foreach ($flowIdClassNameParts as $part) {
            $flowIdClassName .= ucfirst($part);
        }

        $processorClass = "Wetrust\\Actito\\Model\\Flow\\{$flowIdClassName}\\{$directionClassName}";

        if (!class_exists('\\' . $processorClass)) {
            throw new ProcessException('Flow processor (' . $flowIdClassName . '\\' . $directionClassName . ') does not exist');
        }

        return $this->objectManager->create($processorClass);
    }
}

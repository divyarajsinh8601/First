<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Direction implements ArrayInterface
{
    const DIRECTION_IMPORT    = 'import';
    const DIRECTION_EXPORT    = 'export';

    /**
     * @return array
     */
    public function toOptionArray()
    {

        $options = [
            0 => [
                'label' => '',
                'value' => ''
            ],
            1 => [
                'label' => __('Import'),
                'value' => self::DIRECTION_IMPORT
            ],
            2 => [
                'label' => __('Export'),
                'value' => self::DIRECTION_EXPORT
            ],
        ];

        return $options;
    }
}

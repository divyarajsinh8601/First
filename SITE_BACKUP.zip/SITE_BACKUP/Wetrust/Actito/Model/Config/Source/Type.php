<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class Type implements ArrayInterface
{
    const TYPE_AUTO     = 'auto';
    const TYPE_MANUAL   = 'manual';
    const TYPE_MODIFIED   = 'modif';

    /**
     * @return array
     */
    public function toOptionArray()
    {

        $options = [
            0 => [
                'label' => '',
                'value' => ''
            ],
            1 => [
                'label' => __('Auto'),
                'value' => self::TYPE_AUTO
            ],
            2 => [
                'label' => __('Manual'),
                'value' => self::TYPE_MANUAL
            ],
            3  => [
                'label' => __('Modified'),
                'value' => self::TYPE_MODIFIED
            ]
        ];

        return $options;
    }
}

<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use Wetrust\Actito\Helper\Data;

class Status implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            0 => [
                'label' => '',
                'value' => ''
            ],
            1 => [
                'label' => Data::TASK_STATUS_PENDING,
                'value' => Data::TASK_STATUS_PENDING
            ],
            2 => [
                'label' => Data::TASK_STATUS_PROCESSING,
                'value' => Data::TASK_STATUS_PROCESSING
            ],
            3  => [
                'label' => Data::TASK_STATUS_SUCCESS,
                'value' => Data::TASK_STATUS_SUCCESS
            ],
            4 => [
                'label' => Data::TASK_STATUS_ERROR,
                'value' => Data::TASK_STATUS_ERROR
            ],
        ];

        return $options;
    }
}

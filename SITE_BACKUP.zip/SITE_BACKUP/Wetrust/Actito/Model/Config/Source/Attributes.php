<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;

class Attributes implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * Attributes constructor.
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    public function toOptionArray()
    {
        $collection = $this->collectionFactory->create();

        $attributes = [
            ['value' => '', 'label' => '-- Select an attribute --']
        ];

        foreach ($collection->getItems() as $items) {
            $attr = $items->getData();
            $attributes[] = ['value' => $attr['attribute_code'], 'label' => $attr['attribute_code']];
        }

        return $attributes;

    }
}

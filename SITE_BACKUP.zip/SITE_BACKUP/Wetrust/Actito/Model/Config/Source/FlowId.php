<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use phpDocumentor\Reflection\Types\Self_;
use Wetrust\Actito\Helper\Data;

class FlowId implements ArrayInterface
{

    const CUSTOMER     = 'CUSTOMER';
    const ORDER_ITEM     = 'ORDER_ITEM';
    const QUOTE_ITEM     = 'QUOTE_ITEM';
    const NEWSLETTER_SUBSCRIBER = "NEWSLETTER_SUBSCRIBER";
    const QUOTE = "QUOTE";
    CONST ALERT_STOCK = "ALERT_STOCK";


    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            0 => [
                'label' => '',
                'value' => ''
            ],
            1 => [
                'label' => self::CUSTOMER,
                'value' => self::CUSTOMER
            ],
            2 => [
                'label' => self::QUOTE_ITEM,
                'value' => self::QUOTE_ITEM
            ],
            3  => [
                'label' => self::ORDER_ITEM,
                'value' => self::ORDER_ITEM
            ],
            4 => [
                'label' => self::NEWSLETTER_SUBSCRIBER,
                'value' => self::NEWSLETTER_SUBSCRIBER
            ],
            5 => [
                'label' => self::QUOTE,
                'value' => self::QUOTE
            ],
            6 => [
                'label' => self::ALERT_STOCK,
                'value' => self::ALERT_STOCK
            ]
        ];

        return $options;
    }
}

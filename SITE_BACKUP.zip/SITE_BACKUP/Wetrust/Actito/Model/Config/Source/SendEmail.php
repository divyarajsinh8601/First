<?php


namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class SendEmail implements ArrayInterface
{

    public function toOptionArray()
    {
        return [
            0 => __('Send through Magento'),
            1 => __('Export to Actito'),
            2 => __('Export to Actito & send through Magento')
        ];
    }
}

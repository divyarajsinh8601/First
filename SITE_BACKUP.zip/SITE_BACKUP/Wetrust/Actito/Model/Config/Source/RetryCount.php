<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

class RetryCount implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
            0 => [
                'label' => '',
                'value' => ''
            ],
            1 => [
                'label' => '0',
                'value' => 0
            ],
            2 => [
                'label' => '1',
                'value' => 1
            ],
            3  => [
                'label' => '2',
                'value' => 2
            ],
            4 => [
                'label' => '3',
                'value' => 3
            ],
        ];

        return $options;
    }
}

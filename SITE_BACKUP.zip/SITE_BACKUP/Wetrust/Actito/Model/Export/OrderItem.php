<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Export;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Sales\Model\ResourceModel\Order\Item as OrderItemResource;
use Magento\Sales\Model\Order\ItemFactory as OrderItemFactory;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;

class OrderItem extends Export
{
    /**
     * @var OrderItemFactory
     */
    private $orderItemFactory;

    /**
     * @var PricingHelper
     */
    private $pricingHelper;

    /**
     * @var OrderItemResource
     */
    private $orderItemResource;

    /**
     * OrderItem constructor.
     * @param DateTimeFactory $dateTimeFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param ActitoHelper $helper
     * @param Connector $connector
     * @param EmulationFactory $emulationFactory
     * @param StoreManagerInterface $storeManager
     * @param EventManager $eventManager
     * @param OrderItemFactory $orderItemFactory
     * @param OrderItemResource $orderItemResource
     * @param PricingHelper $pricingHelper
     */
    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager,
        //
        OrderItemFactory $orderItemFactory,
        OrderItemResource $orderItemResource,
        PricingHelper $pricingHelper

    ) {
        parent::__construct($dateTimeFactory, $productCollectionFactory, $helper, $connector, $emulationFactory, $storeManager, $eventManager);
        $this->orderItemFactory = $orderItemFactory;
        $this->pricingHelper = $pricingHelper;
        $this->orderItemResource = $orderItemResource;
    }

    public function process(Task $task)
    {
        $orderItemId = $task->getObjId();

        $orderItem = $this->orderItemFactory->create();
        $this->orderItemResource->load($orderItem, $orderItemId);

        $appEmulation = $this->emulationFactory->create();
        $appEmulation->startEnvironmentEmulation($orderItem->getStoreId());
        $productSku = explode('-', $orderItem->getSku());
        $productData = $this->getProductData($productSku[0] . '-' . $productSku[1], 'sku');
        foreach ($productData as $product) {
            $this->connector
                    ->setTask($task)
                    ->setTable($this->helper->getFlowOrderItemTableName())
                    ->setIsCustomTable(true);

            $this->eventManager->dispatch('actito_order_item_request', [
                'connector' => $this->connector,
                'storeManager' => $this->storeManager,
                'orderItem' => $orderItem,
                'product' => $product,
                'helper' => $this->helper,
                'pricingHelper' => $this->pricingHelper
            ]);

            $this->connector->pushData();
        }

        $appEmulation->stopEnvironmentEmulation();
        unset($appEmulation);
    }

}

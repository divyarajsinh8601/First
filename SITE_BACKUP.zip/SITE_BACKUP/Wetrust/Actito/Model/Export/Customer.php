<?php

namespace Wetrust\Actito\Model\Export;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Wetrust\Actito\Api\Data\TaskInterface as Task;

use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory as CustomerCollectionFactory;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Wetrust\Actito\Helper\Customer as CustomerHelper;
use Magento\Customer\Model\ResourceModel\Customer as CustomerResource;
use Wetrust\Actito\Model\Export;

/**
 * Class Customer
 * @package Wetrust\Actito\Model\Export
 */
class Customer extends Export
{
    /**
     * @var CustomerFactory
     */
    private $customerFactory;

    /**
     * @var \Magento\Customer\Model\ResourceModel\Customer
     */
    private $customerResource;

    /**
     * @var OrderCollectionFactory
     */
    private $orderCollectionFactory;

    /**
     * @var CustomerHelper
     */

    private $customerHelper;

    /**
     * Customer constructor.
     * @param DateTimeFactory $dateTimeFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param OrderCollectionFactory $orderCollectionFactory
     * @param ActitoHelper $helper
     * @param Connector $connector
     * @param CustomerFactory $customerFactory
     * @param \Magento\Customer\Model\ResourceModel\Customer $customerResource
     * @param EventManager $eventManager
     */
    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager,
        //
        CustomerHelper $customerHelper,
        CustomerFactory $customerFactory,
        CustomerResource $customerResource,
        OrderCollectionFactory $orderCollectionFactory
    ) {
        parent::__construct($dateTimeFactory, $productCollectionFactory, $helper, $connector, $emulationFactory, $storeManager, $eventManager);
        $this->customerHelper = $customerHelper;
        $this->customerFactory = $customerFactory;
        $this->customerResource = $customerResource;
        $this->orderCollectionFactory = $orderCollectionFactory;
    }

    /**
     * @param Task $task
     */
    public function process(Task $task)
    {
        $customerId = $task->getObjId();

        $customer = $this->customerFactory->create();
        $this->customerResource->load($customer, $customerId);

        if(!$customer->getId()) {
            $task->delete();
        } else {
            $this->connector
                    ->setTask($task)
                    ->setIsCustomTable(false)
                    ->setTable($this->helper->getFlowCustomerTableName());

            $this->eventManager->dispatch('actito_customer_request', [
                'connector' => $this->connector,
                'storeManager' => $this->storeManager,
                'customer' => $customer,
                'helper' => $this->helper,
                'helperCustomer' => $this->customerHelper
            ]);

            $this->connector->pushData();
            $this->helper->log("CustomerData {$customer->getEmail()} sent to actito");
        }
    }
}

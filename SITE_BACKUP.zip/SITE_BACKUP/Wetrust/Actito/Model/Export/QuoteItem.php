<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\Export;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\App\Area;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Quote\Model\QuoteFactory;
use Magento\Quote\Model\ResourceModel\Quote as QuoteResource;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export;
use Magento\Quote\Model\ResourceModel\Quote\CollectionFactory as QuoteCollectionFactory;
use Magento\Quote\Model\ResourceModel\Quote\Item\CollectionFactory as QuoteItemCollectionFactory;
use Wetrust\Actito\Exception\ProcessException;

class QuoteItem extends Export
{
    /**
     * @var QuoteFactory
     */
    private $quoteFactory;
    /**
     * @var QuoteResource
     */
    private $quoteResource;

    /**
     * @var PricingHelper
     */
    private $pricingHelper;

    /**
     * @var QuoteCollectionFactory
     */
    private $quoteCollectionFactory;

    /**
     * @var QuoteItemCollectionFactory|QuoteItemFactory
     */
    private $quoteItemCollectionFactory;

    /**
     * QuoteItem constructor.
     * @param DateTimeFactory $dateTimeFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param ActitoHelper $helper
     * @param Connector $connector
     * @param EmulationFactory $emulationFactory
     * @param StoreManagerInterface $storeManager
     * @param EventManager $eventManager
     * @param QuoteFactory $quoteFactory
     * @param QuoteResource $quoteResource
     * @param QuoteCollectionFactory $quoteCollectionFactory
     * @param PricingHelper $pricingHelper
     * @param QuoteItemFactory $quoteItemCollectionFactory
     */
    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager,
        //
        QuoteFactory $quoteFactory,
        QuoteResource $quoteResource,
        QuoteCollectionFactory $quoteCollectionFactory,
        PricingHelper $pricingHelper,
        QuoteItemCollectionFactory $quoteItemCollectionFactory
    )
    {
        parent::__construct($dateTimeFactory, $productCollectionFactory, $helper, $connector, $emulationFactory, $storeManager, $eventManager);
        $this->quoteFactory = $quoteFactory;
        $this->quoteResource = $quoteResource;
        $this->quoteCollectionFactory = $quoteCollectionFactory;
        $this->pricingHelper = $pricingHelper;
        $this->quoteItemCollectionFactory = $quoteItemCollectionFactory;
    }

    public function process(Task $task)
    {
        $quoteItemCollection = $this->quoteItemCollectionFactory->create();
        $quoteItem = $quoteItemCollection
            ->addFieldToSelect('*')
            ->addFieldToFilter('item_id', $task->getObjId())
            ->getFirstItem();
        if(!$quoteItem->getId()) {
            $task->delete();
        } else {
            $quoteCollection = $this->quoteCollectionFactory->create();
            $quote = $quoteCollection->addFieldToFilter('entity_id', $quoteItem->getQuoteId())->getFirstItem();

            if(!$quote->getId() || $quote->getIsActive() == "0") {
                $task->delete();
            }

            $request = $this->connector
                ->setTask($task)
                ->setTable($this->helper->getMappingQuoteItem())
                ->setIsCustomTable(true)
                ->addRequestData('abandonedCartReference', $quote->getId(), 'GET')
                ->getData();

            $records = $request['records'];

            if (empty($records) || count($records) == 0) {
                throw new ProcessException("There is no match in actito from abandonedCartReference = " . $quote->getId());

            }

            $skus = [];
            foreach ($records as $record) {
                $line = $this->formatProperties($record);
                if (!empty($line['sku']) && $line['sku'] == $quoteItem->getSku() && !in_array($line['sku'], $skus)) {
                    $skus[] = $line['sku'];
                }
            }

            $appEmulation = $this->emulationFactory->create();
            $appEmulation->startEnvironmentEmulation($quote->getStoreId());

            $productData = $this->getProductData($skus, 'sku');
            foreach ($records as $record) {
                $line = $this->formatProperties($record);
                if (!empty($line['sku']) && !empty($productData[$line['sku']])) {
                    $product = $productData[$line['sku']];
                    $this->connector
                        ->setTask($task)
                        ->setTable($this->helper->getMappingQuoteItem())
                        ->setIsCustomTable(true)
                        ->addRequestData('abandonedCartDetailId', $line['businessKey']);

                    $this->eventManager->dispatch('actito_quote_item_request', [
                        'connector' => $this->connector,
                        'storeManager' => $this->storeManager,
                        'quote' => $quote,
                        'quoteItem' => $quoteItem,
                        'product' => $product,
                        'line' => $line,
                        'helper' => $this->helper,
                        'pricingHelper' => $this->pricingHelper
                    ]);

                    $this->connector->pushData();
                }
            }
            $appEmulation->stopEnvironmentEmulation();
            unset($appEmulation);
        }
    }

}

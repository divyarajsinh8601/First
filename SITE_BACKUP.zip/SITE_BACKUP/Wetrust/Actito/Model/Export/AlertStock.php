<?php

namespace Wetrust\Actito\Model\Export;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Pricing\Helper\Data as PricingHelper;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Export;

class AlertStock extends Export
{

    /**
     * @var PricingHelper
     */
    protected $pricingHelper;

    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager,
        PricingHelper $pricingHelper
    ) {
        $this->pricingHelper = $pricingHelper;
        parent::__construct(
            $dateTimeFactory,
            $productCollectionFactory,
            $helper,
            $connector,
            $emulationFactory,
            $storeManager,
            $eventManager
        );
    }

    public function process(Task $task)
    {
        /** @var \Magento\ProductAlert\Model\Stock $alert */
        $alert = $this->helper->getAlertStockCollection()
            ->addFieldToFilter('alert_stock_id', $task->getObjId())
            ->getFirstItem();

        $appEmulation = $this->emulationFactory->create();
        $appEmulation->startEnvironmentEmulation($alert->getStoreId());

        $id = $alert->getProductId();
        $products = $this->getProductData([$id]);

        if(isset($products[$id])) {
            $request = $this->connector
            ->setTask($task)
            ->setTable($this->helper->getMappingAlertStock())
            ->setIsCustomTable(true);
            $this->eventManager->dispatch('actito_alert_stock_request', [
                'connector' => $this->connector,
                'storeManager' => $this->storeManager,
                'alert' => $alert,
                'product' => $products[$id],
                'helper' => $this->helper,
                'pricingHelper' => $this->pricingHelper
            ]);

            $this->connector->pushData();
        } else {
            $task->delete();
        }
        $appEmulation->stopEnvironmentEmulation();
        unset($appEmulation);
    }
}

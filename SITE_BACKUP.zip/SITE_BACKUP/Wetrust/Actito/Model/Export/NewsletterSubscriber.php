<?php

namespace Wetrust\Actito\Model\Export;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Wetrust\Actito\Helper\Connector;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Magento\Store\Model\App\EmulationFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Wetrust\Actito\Model\Export;
use Wetrust\Actito\Api\Data\TaskInterface as Task;

//
use Magento\Customer\Api\CustomerRepositoryInterface as CustomerRepository;
use Magento\Customer\Api\Data\CustomerInterface;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Framework\Api\ExtensionAttributesFactory;
use Magento\Newsletter\Model\ResourceModel\Subscriber;
use Magento\Customer\Api\Data\CustomerExtensionInterface;


/**
 * Class Customer
 * @package Wetrust\Actito\Model\Export
 */
class NewsletterSubscriber extends Export
{
    /**
     * Factory used for manipulating newsletter subscriptions
     *
     * @var SubscriberFactory
     */
    private $subscriberFactory;

    /**
     * @var ExtensionAttributesFactory
     */
    private $extensionFactory;

    /**
     * @var Subscriber
     */
    private $subscriberResource;

    /**
     * @var array
     */
    private $customerSubscriptionStatus = [];


    /**
     * Customer constructor.
     * @param DateTimeFactory $dateTimeFactory
     * @param ProductCollectionFactory $productCollectionFactory
     * @param OrderCollectionFactory $orderCollectionFactory
     * @param ActitoHelper $helper
     * @param Connector $connector
     * @param CustomerFactory $customerFactory
     * @param \Magento\Customer\Model\ResourceModel\Customer $customerResource
     * @param EventManager $eventManager
     */
    public function __construct(
        DateTimeFactory $dateTimeFactory,
        ProductCollectionFactory $productCollectionFactory,
        ActitoHelper $helper,
        Connector $connector,
        EmulationFactory $emulationFactory,
        StoreManagerInterface $storeManager,
        EventManager $eventManager,
        //
        Subscriber $subscriberResource,
        SubscriberFactory $subscriberFactory,
        ExtensionAttributesFactory $extensionFactory
    )
    {
        parent::__construct($dateTimeFactory, $productCollectionFactory, $helper, $connector, $emulationFactory, $storeManager, $eventManager);
        $this->subscriberResource = $subscriberResource;
        $this->subscriberFactory = $subscriberFactory;
        $this->extensionFactory = $extensionFactory;
    }

    /**
     * @param Task $task
     */
    public function process(Task $task)
    {
        $subscriberId = $task->getObjId();

        $subscriber = $this->subscriberFactory->create();
        $this->subscriberResource->load($subscriber, $subscriberId);

        if(!$subscriber->getId()) {
            $task->delete();
        }  else {
            $this->connector
                ->setTask($task)
                ->setTable($this->helper->getFlowNewsletterSubscriberTableName())
                ->setIsCustomTable(false);

            $this->eventManager->dispatch('actito_newsletter_subscriber_request', [
                'connector' => $this->connector,
                'storeManager' => $this->storeManager,
                'subscriber' => $subscriber,
                'helper' => $this->helper
            ]);
            $this->connector->pushData();
            $this->helper->log("NewsletterSubscriber {$subscriber->getSubscriberEmail()} sent to actito");
        }

    }
}

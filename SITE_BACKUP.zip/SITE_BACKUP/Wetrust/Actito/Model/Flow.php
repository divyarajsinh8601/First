<?php declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Exception;
use Wetrust\Actito\Api\Data\TaskInterface as Task;
use Wetrust\Actito\Api\FlowInterface;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Exception\ProcessException;
use Wetrust\Actito\Helper\Data as ActitoHelper;

abstract class Flow implements FlowInterface
{
    /**
     * @var ActitoHelper
     */
    protected $helper;

    /**
     * @var TaskRepositoryInterface
     */
    private $taskRepository;

    /**
     * Flow constructor.
     * @param ActitoHelper $helper
     * @param TaskRepositoryInterface $taskRepository
     */
    public function __construct(
        ActitoHelper $helper,
        TaskRepositoryInterface $taskRepository
    )
    {
        $this->helper = $helper;
        $this->taskRepository = $taskRepository;
    }

    /**
     * @inheritdoc
     */
    public function launchProcess(Task $task): void
    {
        try {
            $this->beforeProcess($task);
            $this->process($task);
            $this->processSuccess($task);
        } catch (ProcessException $e) {
            $this->processError($task, $e);
        }
    }

    /**
     * If a Process Exception has been thrown than re-queue task or if to much retries set status to error
     *
     * @param Task $task
     * @param ProcessException $exception
     */
    protected function processError(Task $task, ProcessException $exception): void
    {
        $task->setMessages($exception->getMessage());
        if ($task->getRetryCount() >= $this->helper->getMaxRetryBeforeError()) {
            $task->setStatus(Task::STATUS_ERROR);
        } else {
            $task->setStatus(Task::STATUS_PENDING);
            $task->increaseRetryCount();
        }

        try {
            $this->taskRepository->save($task);
        } catch (Exception $e) {
            $this->helper->log($e->getMessage());
        }
    }

    /**
     * Before the process start, you can call this method to prepare some actions
     *
     * @param Task $task
     * @return mixed
     */
    protected function beforeProcess(Task $task): void
    {
        try {
            $this->taskRepository->save($task);
        } catch (Exception $e) {
            $this->helper->log($e->getMessage());
        }
    }

    /**
     * Start the process
     * @param Task $task
     * @return mixed
     * @throws ProcessException
     */
    abstract protected function process(Task $task): void;

    /**
     * If the process finished without errors then change status to success
     *
     * @param Task $task
     * @throws \Magento\Framework\Exception\AlreadyExistsException
     */
    protected function processSuccess(Task $task): void
    {
        try {
            if (is_null($task->getRequest())) {
                if ($task->getRetryCount() >= $this->helper->getMaxRetryBeforeError()) {
                    $task->setStatus(Task::STATUS_ERROR);
                } else {
                    $task->setStatus(Task::STATUS_PENDING);
                }
                $task->increaseRetryCount();

            } else {
                if ($task->getRetryCount() >= $this->helper->getMaxRetryBeforeError()) {
                    $task->setStatus(Task::STATUS_ERROR);
                } else {
                    $task->setStatus(Task::STATUS_SUCCESS);
                }
            }

            $this->taskRepository->save($task);

        } catch (Exception $e) {
            $this->helper->log($e->getMessage());
        }
    }
}

<?php
declare(strict_types=1);

namespace Wetrust\Actito\Model\Profile;

use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Wetrust\Actito\Model\ResourceModel\Profile\CollectionFactory;
use Magento\Framework\UrlInterface;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;

    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /** Url Path */
    const CUSTOMER_URL_PATH_EDIT = 'customer/index/edit';


    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param UrlInterface $urlBuilder
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        UrlInterface $urlBuilder,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()]['general'] = $model->getData();
            $customerUrl = $this->urlBuilder->getUrl(self::CUSTOMER_URL_PATH_EDIT, ['id' => $model->getData('customer_id')]);
            $this->loadedData[$model->getId()]['general']['customer'][0] = $customerUrl;
            $this->loadedData[$model->getId()]['general']['customer'][1] = $model->getData('customer_id');
        }
        $data = $this->dataPersistor->get('actito_profile');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()]['general'] = $model->getData();
            $customerUrl = $this->urlBuilder->getUrl(self::CUSTOMER_URL_PATH_EDIT, ['id' => $model->getData('customer_id')]);
            $this->loadedData[$model->getId()]['general']['customer'][0] = $customerUrl;
            $this->loadedData[$model->getId()]['general']['customer'][1] = $model->getData('customer_id');
            $this->dataPersistor->clear('actito_profile');
        }

        return $this->loadedData;
    }
}
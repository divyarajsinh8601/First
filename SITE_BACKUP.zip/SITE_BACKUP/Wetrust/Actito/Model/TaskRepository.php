<?php declare(strict_types=1);
namespace Wetrust\Actito\Model;

use Magento\Framework\Api\FilterBuilder;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResults;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Wetrust\Actito\Api\Data\TaskInterface;
use Wetrust\Actito\Api\Data\TaskSearchResultsInterfaceFactory;
use Wetrust\Actito\Api\TaskRepositoryInterface;
use Wetrust\Actito\Model\ResourceModel\Task as TaskResource;
use Wetrust\Actito\Model\ResourceModel\Task\Collection as TaskCollection;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory as TaskCollectionFactory;

class TaskRepository implements TaskRepositoryInterface
{
    /**
     * @var TaskResource
     */
    private $resource;
    /**
     * @var TaskFactory
     */
    private $taskFactory;
    /**
     * @var TaskSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;
    /**
     * @var TaskCollectionFactory
     */
    private $taskCollectionFactory;

    private $filterBuilder;

    private $searchCriteriaBuilder;

    /**
     * TaskRepository constructor.
     * @param ResourceModel\Task $resource
     * @param TaskFactory $taskFactory
     * @param TaskResource\Collection $taskCollectionFactory
     * @param TaskSearchResultsInterfaceFactory $searchResultsFactory
     */
    public function __construct(
        TaskResource $resource,
        TaskFactory $taskFactory,
        TaskCollectionFactory $taskCollectionFactory,
        TaskSearchResultsInterfaceFactory $searchResultsFactory,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        FilterBuilder $filterBuilder
    ) {
        $this->resource = $resource;
        $this->taskFactory = $taskFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->taskCollectionFactory = $taskCollectionFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
    }

    /**
     * @inheritdoc
     */
    public function save(TaskInterface $task): TaskInterface
    {
        try {
            $this->resource->save($task);
        } catch (\Zend_Db_Statement_Exception $e) {
            $filters = [];
            $filters[] = $this->filterBuilder
                ->setField('flow_id')
                ->setValue($task->getFlowId())
                ->create();

            $filters[] = $this->filterBuilder
                ->setField('obj_id')
                ->setValue($task->getObjId())
                ->create();

            $filters[] = $this->filterBuilder
                ->setField('direction')
                ->setValue($task->getDirection())
                ->create();

            $task = current(
                $this->getList(
                    $this->searchCriteriaBuilder
                        ->addFilters($filters)
                        ->create()
                )->getItems()
            );

            if (!$task) {
                throw $e;
            }
        }

        return $task;
    }

    /**
     * @inheritdoc
     */
    public function getById($taskId): TaskInterface
    {
        return $this->get($taskId);
    }

    /**
     * @inheritdoc
     */
    public function get($value, $attributeCode = null): TaskInterface
    {
        $task = $this->taskFactory->create();
        $this->resource->load($task, $value, $attributeCode);

        if (!$task->getId()) {
            throw new NoSuchEntityException(__('Unable to find Actito task'));
        }

        return $task;
    }

    /**
     * @inheritdoc
     */
    public function delete(TaskInterface $task): bool
    {
        try {
            $this->resource->delete($task->getId());
        } catch (\Exception $e) {
            throw new CouldNotDeleteException(_($e->getMessage()));
        }

        return true;
    }

    /**
     * @inheritdoc
     */
    public function deleteById($taskId): bool
    {
        $task = $this->getById($taskId);

        return $this->delete($task);
    }

    /**
     * @inheritdoc
     */
    public function getList(SearchCriteriaInterface $searchCriteria): SearchResults
    {
        $collection = $this->taskCollectionFactory->create();

        $this->addFilterstoCollection($searchCriteria, $collection);
        $this->addSortOrdersToCollection($searchCriteria, $collection);
        $this->addPagingToCollection($searchCriteria, $collection);

        $collection->load();

        return $this->buildSearchResult($searchCriteria, $collection);
    }

    protected function addFiltersToCollection(SearchCriteriaInterface $searchCriteria, TaskCollection $collection)
    {
        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }
    }

    protected function addSortOrdersToCollection(SearchCriteriaInterface $searchCriteria, TaskCollection $collection)
    {
        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($searchCriteria->getSortOrders() as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
    }

    protected function addPagingToCollection(SearchCriteriaInterface $searchCriteria, TaskCollection $collection)
    {
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @param TaskCollection $collection
     * @return \Magento\Framework\Api\SearchResults
     */
    protected function buildSearchResult(SearchCriteriaInterface $searchCriteria, TaskCollection $collection): \Magento\Framework\Api\SearchResults
    {
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());

        return $searchResults;
    }
}

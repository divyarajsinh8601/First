<?php
declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Magento\Framework\Model\AbstractModel;
use Wetrust\Actito\Api\Data\InteractionInterface;

class Interaction extends AbstractModel implements InteractionInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Wetrust\Actito\Model\ResourceModel\Interaction::class);
    }

    /**
     * @inheritDoc
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * @inheritDoc
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * @inheritDoc
     */
    public function getProfileId()
    {
        return $this->getData(self::PROFILE_ID);
    }

    /**
     * @inheritDoc
     */
    public function setProfileId($profileId)
    {
        return $this->setData(self::PROFILE_ID, $profileId);
    }

    /**
     * @inheritDoc
     */
    public function getProfileSubscriptionId()
    {
        return $this->getData(self::PROFILE_SUBSCRIPTION_ID);
    }

    /**
     * @inheritDoc
     */
    public function setProfileSubscriptionId($profileSubscriptionId)
    {
        return $this->setData(self::PROFILE_SUBSCRIPTION_ID, $profileSubscriptionId);
    }

    /**
     * @inheritDoc
     */
    public function getOrigin()
    {
        return $this->getData(self::ORIGIN);
    }

    /**
     * @inheritDoc
     */
    public function setOrigin($origin)
    {
        return $this->setData(self::ORIGIN, $origin);
    }

    /**
     * @inheritDoc
     */
    public function getPosition()
    {
        return $this->getData(self::POSITION);
    }

    /**
     * @inheritDoc
     */
    public function setPosition($position)
    {
        return $this->setData(self::POSITION, $position);
    }

    /**
     * @inheritDoc
     */
    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * @inheritDoc
     */
    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

    /**
     * @inheritDoc
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}
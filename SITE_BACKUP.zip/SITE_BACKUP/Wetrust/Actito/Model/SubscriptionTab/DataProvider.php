<?php
namespace Wetrust\Actito\Model\SubscriptionTab;

use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Wetrust\Actito\Model\ResourceModel\Subscription\CollectionFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Framework\App\RequestInterface;

class DataProvider extends AbstractDataProvider
{

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @inheritDoc
     */
    protected $collection;
    
    protected $formKey;

     private $request;

    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        FormKey $formKey,
        RequestInterface $request,
        \Magento\Framework\Registry $registry,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->formKey = $formKey;
         $this->request = $request;
             $this->_registry = $registry;

        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        $profileId = $this->dataPersistor->get('profile_id');
      
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }       

        $this->collection = $this->collection->addFieldToFilter('profile_id',['eq'=>$profileId]);

        
        
        $items = $this->collection->getItems();

        foreach ($items as $model) {
            $this->loadedData['items'][] = $model->getData();
        }
        $this->loadedData['totalRecords'] = $this->collection->count();
        $data = $this->dataPersistor->get('actito_profile_subscription');
        
        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData['items'][] = $model->getData();
            $this->dataPersistor->clear('actito_profile_subscription');
        }
        // echo "<pre>";
        // print_r($this->loadedData);
        // exit;
        return $this->loadedData;
	}

}

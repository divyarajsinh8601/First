<?php
declare(strict_types=1);

namespace Wetrust\Actito\Model;

use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Wetrust\Actito\Api\Data\InteractionInterface;
use Wetrust\Actito\Api\Data\InteractionInterfaceFactory;
use Wetrust\Actito\Api\Data\InteractionSearchResultsInterfaceFactory;
use Wetrust\Actito\Api\InteractionRepositoryInterface;
use Wetrust\Actito\Model\ResourceModel\Interaction as ResourceInteraction;
use Wetrust\Actito\Model\ResourceModel\Interaction\CollectionFactory as InteractionCollectionFactory;

class InteractionRepository implements InteractionRepositoryInterface
{

    /**
     * @var InteractionCollectionFactory
     */
    protected $interactionCollectionFactory;

    /**
     * @var ResourceInteraction
     */
    protected $resource;

    /**
     * @var Interaction
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var InteractionInterfaceFactory
     */
    protected $interactionFactory;


    /**
     * @param ResourceInteraction $resource
     * @param InteractionInterfaceFactory $interactionFactory
     * @param InteractionCollectionFactory $interactionCollectionFactory
     * @param InteractionSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceInteraction $resource,
        InteractionInterfaceFactory $interactionFactory,
        InteractionCollectionFactory $interactionCollectionFactory,
        InteractionSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->interactionFactory = $interactionFactory;
        $this->interactionCollectionFactory = $interactionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(InteractionInterface $interaction)
    {
        try {
            $this->resource->save($interaction);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the Profile  Interaction: %1',
                $exception->getMessage()
            ));
        }
        return $interaction;
    }

    /**
     * @inheritDoc
     */
    public function get($interactionId)
    {
        $interaction = $this->interactionFactory->create();
        $this->resource->load($interaction, $interactionId);
        if (!$interaction->getId()) {
            throw new NoSuchEntityException(__('Profile Interaction with id "%1" does not exist.', $interactionId));
        }
        return $interaction;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->interactionCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(InteractionInterface $interaction)
    {
        try {
            $interactionModel = $this->interactionFactory->create();
            $this->resource->load($interactionModel, $interaction->getInteractionId());
            $this->resource->delete($interactionModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Profile Interaction: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($interactionId)
    {
        return $this->delete($this->get($interactionId));
    }
}
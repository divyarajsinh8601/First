<?php declare(strict_types=1);

namespace Wetrust\Actito\Model\ResourceModel\Task;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Wetrust\Actito\Model\Task;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'job_id';
    protected $_eventPrefix = Task::CACHE_TAG . '_collection';
    protected $_eventObject = 'task_collection';

    protected function _construct()
    {
        $this->_init('Wetrust\Actito\Model\Task', 'Wetrust\Actito\Model\ResourceModel\Task');
    }
}

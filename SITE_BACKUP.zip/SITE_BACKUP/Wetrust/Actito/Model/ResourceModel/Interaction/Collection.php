<?php
declare(strict_types=1);

namespace Wetrust\Actito\Model\ResourceModel\Interaction;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'entity_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Wetrust\Actito\Model\Interaction::class,
            \Wetrust\Actito\Model\ResourceModel\Interaction::class
        );
    }
}

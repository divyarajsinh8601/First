<?php
declare(strict_types=1);

namespace Wetrust\Actito\Model\ResourceModel\Profile;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'entity_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Wetrust\Actito\Model\Profile::class,
            \Wetrust\Actito\Model\ResourceModel\Profile::class
        );
    }
}


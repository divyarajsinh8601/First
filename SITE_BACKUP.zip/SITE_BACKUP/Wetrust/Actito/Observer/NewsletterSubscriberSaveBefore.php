<?php
namespace Wetrust\Actito\Observer;

use Magento\Framework\Event\ObserverInterface;

class NewsletterSubscriberSaveBefore implements ObserverInterface
{
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $subscriber = $observer->getEvent()->getSubscriber();
        if(!$subscriber->getImportMode()){
            $subscriber->setActitoSync(1);
        }

        return $this;
    }
}

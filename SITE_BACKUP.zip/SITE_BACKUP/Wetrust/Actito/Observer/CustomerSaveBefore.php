<?php
namespace Wetrust\Actito\Observer;

use Magento\Framework\Event\ObserverInterface;

class CustomerSaveBefore implements ObserverInterface
{
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $customer = $observer->getEvent()->getCustomer();
        $customer->setActitoSync(1);

        if (!empty($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $acceptedLanguage = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
            $acceptedLanguage = $acceptedLanguage[0];
            if ($customer->getAcceptLanguage() != $acceptedLanguage) {
                $customer->setData('accept_language', $acceptedLanguage);
            }
        }

        if (!empty($_SERVER['HTTP_CF_IPCOUNTRY'])) {
            $cfCountryCode = $_SERVER['HTTP_CF_IPCOUNTRY'];
            if ($customer->getIpCountry() != $cfCountryCode) {
                $customer->setData('ip_country', $cfCountryCode);
            }
        }
        
        return $this;
    }
}

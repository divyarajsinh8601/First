<?php
namespace Wetrust\Actito\Controller\Adminhtml\Task;

use Magento\Backend\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory;
use Wetrust\Actito\Model\FlowFactory;
use Exception;

/**
 * Class massDelete
 * @package Wetrust\Actito\Controller\Adminhtml\Task
 */
class MassDelete extends Action
{
    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var FlowFactory
     */
    protected $flowFactory;

    /**
     * massDelete constructor.
     * @param Action\Context $context
     * @param CollectionFactory $collectionFactory
     * @param FlowFactory $flowFactory
     */
    public function __construct(Action\Context $context, CollectionFactory $collectionFactory, FlowFactory $flowFactory)
    {
        $this->collectionFactory = $collectionFactory;
        $this->flowFactory = $flowFactory;
        parent::__construct($context);
    }


    /**
     * @return $this
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        $ids = $this->_request->getPost('job_id');
        if (empty($ids)) {
            $this->messageManager->addErrorMessage(__('Error. No jobs ids have been sent.'));
            return $resultRedirect->setPath('*/*/');
        }

        try {
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('job_id', ['in' => $ids]);
            $i = 0;
            foreach ($collection as $task) {
                $task->delete();
                $i++;
            } 
            $this->messageManager->addSuccessMessage(sprintf(__('%d task(s) Deleted successfully'), $i));
        } catch (Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }

        return $resultRedirect->setPath('*/*/');
    }
}

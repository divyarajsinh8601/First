<?php

namespace Wetrust\Actito\Controller\Adminhtml\Task;

use Exception;
use Magento\Backend\App\Action;
use Magento\Framework\Exception\LocalizedException;

use Wetrust\Actito\Model\TaskRepository;

class Save extends Action
{

    /**
     * @var TaskRepository
     */
    protected $_taskRepository;

    /**
     * @param TaskRepository $taskRepository
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
        TaskRepository $taskRepository,
        Action\Context $context
    ) {
        parent::__construct($context);
        $this->_taskRepository = $taskRepository;
    }

    /**
     * Execute action based on request and return result
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            $this->messageManager->addErrorMessage(__('Invalid form key'));
            return $resultRedirect->setPath('*/*/');
        }

        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $task = $this->_taskRepository->get($this->getRequest()->getParam('job_id'));

            $task->setData('retry_count', $data['retry_count']);
            $task->setData('request', $data['request']);
            $task->setData('status', $data['status']);
            $task->setData('messages', $data['messages']);

            try {
                $this->_taskRepository->save($task);
                $this->messageManager->addSuccessMessage(__('Task has been successfully saved'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the task.'));
            }
        }

        return $resultRedirect->setPath('*/*/');
    }
}

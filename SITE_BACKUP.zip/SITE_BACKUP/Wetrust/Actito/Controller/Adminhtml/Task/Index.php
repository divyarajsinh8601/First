<?php declare(strict_types=1);

namespace Wetrust\Actito\Controller\Adminhtml\Task;

use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;

class Index extends \Magento\Backend\App\Action
{
    protected $resultPageFactory = false;

    /**
     * @return ResponseInterface|ResultInterface|Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $resultPage->setActiveMenu('Wetrust_Actito::task_list');
        $resultPage->getConfig()->getTitle()->prepend(__('Actito: Task list'));
        $resultPage->addBreadcrumb(__('Actito: Task list'), __('Actito: Task list'));

        return $resultPage;
    }
}

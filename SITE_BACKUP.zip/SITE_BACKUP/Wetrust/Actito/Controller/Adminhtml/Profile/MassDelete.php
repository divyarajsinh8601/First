<?php
declare(strict_types=1);

namespace Wetrust\Actito\Controller\Adminhtml\Profile;

use Magento\Framework\Exception\LocalizedException;
use Magento\Ui\Component\MassAction\Filter;
use Wetrust\Actito\Model\ResourceModel\Profile\CollectionFactory as ProfileCollectionFactory;
use Magento\Backend\App\Action\Context;

class MassDelete extends \Magento\Backend\App\Action
{
    /**
	 * @var ProfileCollectionFactory
	 */
    protected $profileCollectionFactory;

    /**
	 * @var Filter
	 */
	protected $filter;
 
    /**
     * @param Context $context
     * @param Filter $filter
     * @param ProfileCollectionFactory $profileCollectionFactory
     */
    public function __construct(
        Context $context,
        Filter $filter,
        ProfileCollectionFactory $profileCollectionFactory
    ) {
        $this->filter = $filter;
        $this->profileCollectionFactory = $profileCollectionFactory;
        parent::__construct($context);
    }

    /**
     * Mass Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $profileCollection = $this->filter->getCollection($this->profileCollectionFactory->create());
        $profileCollectionSize = $profileCollection->getSize(); 

        if($profileCollectionSize > 0){ 

            try {                        

                foreach ($profileCollection as $item) { 
                   $item->delete(); 
                }
                $this->messageManager->addSuccessMessage(__('A total of %1 Records have been Deleted.', $profileCollectionSize));      

            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                echo $e;
                exit;
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while Sync the Actito.'));
            } 
        }        
        return $resultRedirect->setPath('*/*/');           
    }
}
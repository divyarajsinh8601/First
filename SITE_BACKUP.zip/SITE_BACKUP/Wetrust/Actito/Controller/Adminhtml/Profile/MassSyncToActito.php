<?php
declare(strict_types=1);

namespace Wetrust\Actito\Controller\Adminhtml\Profile;

use Magento\Framework\Exception\LocalizedException;
use Wetrust\Actito\Helper\Data as HelperData;
use Magento\Ui\Component\MassAction\Filter;
use Wetrust\Actito\Model\ResourceModel\Profile\CollectionFactory as ProfileCollectionFactory;
use Magento\Backend\App\Action\Context;

class Masssynctoactito extends \Magento\Backend\App\Action
{
     /**
	 * @var ProfileCollectionFactory
	 */
    protected $profileCollectionFactory;

    /**
	 * @var Filter
	 */
	protected $filter;
 
    /**
     * @param Context $context
     * @param Filter $filter
     * @param ProfileCollectionFactory $profileCollectionFactory
    */
    public function __construct(
        Context $context,
        Filter $filter,
        ProfileCollectionFactory $profileCollectionFactory
    ) {
        $this->filter = $filter;
        $this->profileCollectionFactory = $profileCollectionFactory;
        parent::__construct($context);
    }

    /**
     * Mass Sync to Actito action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        $profileCollection = $this->filter->getCollection($this->profileCollectionFactory->create());
        $profileCollectionSize = $profileCollection->getSize(); 

        if($profileCollectionSize > 0){ 

            try {    

                foreach ($profileCollection as $item) { 
                   $item->setActitoSync(HelperData::PROFILE_SYNC_ENABLE);              
                   $item->save(); 
                }
                $this->messageManager->addSuccessMessage(__('A total of %1 Records have been Sync.', $profileCollectionSize));      

            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while Sync the Actito.'));
            } 
        }        
        return $resultRedirect->setPath('*/*/');           
    }
}
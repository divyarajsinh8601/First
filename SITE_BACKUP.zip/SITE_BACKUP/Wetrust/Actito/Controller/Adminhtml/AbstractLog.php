<?php declare(strict_types=1);

namespace Wetrust\Actito\Controller\Adminhtml;

use Magento\Backend\App\Action;

abstract class AbstractLog extends Action
{
    const ADMIN_RESOURCE = 'Wetrust_Actito::log_list';
}

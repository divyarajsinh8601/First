<?php
namespace Wetrust\Actito\Block\Adminhtml\Task;

use Magento\Backend\Block\Widget\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Class BackButton
 * @package Wetrust\Actito\Block\Adminhtml\Task
 */
class BackButton implements ButtonProviderInterface
{
    /**
     * @var Context
     */
    protected $context;

    /**
     * @param Context $context
     */
    public function __construct(Context $context)
    {
        $this->context = $context;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getButtonData()
    {
        return [
            'label'         => __('Back'),
            'on_click'      => sprintf("location.href = '%s';", $this->getBackUrl()),
            'class'         => 'back',
            'sort_order'    => 10
        ];
    }

    /**
     * Generate url by route and parameters
     *
     * @param   string $route
     * @param   array $params
     * @return  string
     */
    public function getUrl($route = '', $params = [])
    {
        return $this->context->getUrlBuilder()->getUrl($route, $params);
    }

    /**
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }
}

<?php declare(strict_types=1);

namespace Wetrust\Actito\Block\Adminhtml;

use Magento\Backend\Block\Widget\Grid\Container;

class Task extends Container
{

    protected function _construct()
    {
        $this->_controller = 'adminhtml_task';
        $this->_blockGroup = 'Wetrust_Actito';
        $this->_headerText = __('Task list');
        parent::_construct();

        $this->buttonList->remove('add');
    }
}

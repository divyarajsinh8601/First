<?php declare(strict_types=1);

namespace Wetrust\Actito\Logger;

use Magento\Framework\Filesystem\DriverInterface;
use Magento\Framework\Logger\Handler\Base;

class Handler extends Base
{
    protected $loggerType = Logger::INFO;

    protected $fileName = BP . '/var/log/Wetrust_actito.log';
}

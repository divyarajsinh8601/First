<?php declare(strict_types=1);

namespace Wetrust\Actito\Logger;

class Logger extends \Monolog\Logger
{

}

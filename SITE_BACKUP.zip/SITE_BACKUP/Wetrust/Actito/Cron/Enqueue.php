<?php declare(strict_types=1);

namespace Wetrust\Actito\Cron;

use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Framework\App\Config\Scope\ReaderInterface;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Newsletter\Model\ResourceModel\Subscriber\CollectionFactory as SubscriberResource;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\Task;
use Magento\Customer\Model\ResourceModel\CustomerFactory as CustomerResourceFactory;

class Enqueue
{
    const ACTITO_SYNC = 'actito_sync';
    /**
     * @var \Wetrust\Actito\Helper\Data
     */
    protected $helper;
    /**
     * @var \Wetrust\Actito\Model\TaskRepository
     */
    protected $taskRepository;
    /**
     * @var \Wetrust\Actito\Api\Data\TaskInterfaceFactory
     */
    protected $taskFactory;

    protected $configWriter;

    protected $quoteItemCollectionFactory;

    protected $orderItemFactory;

    protected $subscriberFactory;


    /**
     * Enqueue constructor.
     * @param \Wetrust\Actito\Helper\Data $helper
     * @param \Wetrust\Actito\Model\Task $taskModel
     * @param \Wetrust\Actito\Model\TaskRepository $taskRepository
     */
    public function __construct(
        \Wetrust\Actito\Helper\Data $helper,
        \Wetrust\Actito\Api\Data\TaskInterfaceFactory $taskFactory,
        \Wetrust\Actito\Api\TaskRepositoryInterface $taskRepository,
        \Magento\Quote\Model\ResourceModel\Quote\Item\CollectionFactory $quoteItemCollectionFactory,
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerFactory,
        \Magento\Sales\Model\Order\ItemFactory $orderItemFactory,
        WriterInterface $configWriter,
        CustomerResourceFactory $customerResourceFactory,
        SubscriberFactory $subscriberFactory,
        SubscriberResource $subscriberResource
    )
    {
        $this->helper = $helper;
        $this->taskFactory = $taskFactory;
        $this->taskRepository = $taskRepository;
        $this->quoteItemCollectionFactory = $quoteItemCollectionFactory;
        $this->subscriberFactory = $subscriberFactory;
        $this->subscriberResource = $subscriberResource;
        $this->orderItemFactory = $orderItemFactory;
        $this->customerFactory = $customerFactory;
        $this->configWriter = $configWriter;
        $this->customerResourceFactory = $customerResourceFactory;
    }

    public function execute()
    {
        foreach ($this->helper->getEnabledFlows() as $flowId => $status) {
            if ($status) {
                $methodName = 'handle' . str_replace('_', '', ucwords(strtolower($flowId), '_'));
                call_user_func([$this, $methodName]);
            }
        }
    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function handleCustomer()
    {
        echo "\r\n ------ handleCustomer ------ \r\n";

        $customerCollection = $this->customerFactory->create();

        if ($startEntityId = $this->helper->getFlowCustomerLastEntityId()) {
            $customerCollection->addFieldToFilter('entity_id', ['gt' => $startEntityId]);
        }

        $customerCollection
            ->addAttributeToFilter(self::ACTITO_SYNC, 1);

        echo $customerCollection->getSelect() . "\r\n";

        foreach ($customerCollection as $customer) {
            /** @var Task $task */
            $task = $this->taskFactory->create();

            try {
                $task->enqueue(
                    \Wetrust\Actito\Model\Flow\Customer\Export::FLOW_ID,
                    ActitoHelper::TASK_DIRECTION_EXPORT,
                    $customer->getId());

                $customerData = $customer->getDataModel();
                $customerData->setCustomAttribute(self::ACTITO_SYNC, 0);
                $customer->updateData($customerData);
                $customerResource = $this->customerResourceFactory->create();
                $customerResource->saveAttribute($customer, self::ACTITO_SYNC);
                echo "creating task for " . $customer->getEmail() . "\r\n";
            } catch (\Exception $e) {
                echo "## ERROR ##  " . $e->getMessage() . "\r\n";
            }

        }


    }

    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function handleOrderItem()
    {
        echo "\r\n ------ handleOrderItem ------ \r\n";

        $orderItemCollection = $this->orderItemFactory->create()->getCollection();

        if ($startEntityId = $this->helper->getFlowOrderItemLastEntityId()) {
            $orderItemCollection->addAttributeToFilter('order_id', ['gt' => $startEntityId]);
        }

        $orderItemCollection
            ->addFieldToFilter('main_table.updated_at', array('lt' => $this->helper->getIntervalDate("60")))
            ->addFieldToFilter(self::ACTITO_SYNC, 1)
            ->addFieldToFilter('product_type', array("nin" => ["simple", "bundle", "amgiftcard"]))
            ->join(
                ["so" => "sales_order"],
                'main_table.order_id = so.entity_id',
                ['customer_id']
            );

        echo $orderItemCollection->getSelect() . "\r\n";

        foreach ($orderItemCollection as $orderItem) {
            /** @var Task $taskOrderItem */
            $taskOrderItem = $this->taskFactory->create();
            /** @var Task $taskCustomer */
            $taskCustomer = $this->taskFactory->create();

            try {
                $taskOrderItem->enqueue(
                    \Wetrust\Actito\Model\Flow\OrderItem\Export::FLOW_ID,
                    ActitoHelper::TASK_DIRECTION_EXPORT,
                    $orderItem->getId()
                );
                $orderItem->setActitoSync(0);
                $orderItem->save();
                echo "creating task for Order Item " . $orderItem->getOrderId() . "\r\n";

                if ($orderItem->getCustomerId()) {
                    $taskCustomer->enqueue(
                        \Wetrust\Actito\Model\Flow\Customer\Export::FLOW_ID,
                        ActitoHelper::TASK_DIRECTION_EXPORT,
                        $orderItem->getCustomerId()
                    );
                    echo "creating task for Customer " . $orderItem->getCustomerId() . "\r\n";
                }

            } catch (\Exception $e) {
                echo "## ERROR ##  " . $e->getMessage() . "\r\n";
            }

        }

    }

    protected function handleQuote()
    {
        return $this;
    }
    /**
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function handleQuoteItem()
    {
        echo "\r\n ------ handleQuoteItem ------ \r\n";

        $quoteItemCollection = $this->quoteItemCollectionFactory->create();

        if ($startEntityId = $this->helper->getFlowQuoteItemLastEntityId()) {
            $quoteItemCollection->addFieldToFilter('quote_id', ['gt' => $startEntityId]);
        }

        $quoteItemCollection
            ->addFieldToFilter('main_table.updated_at', array('lt' => $this->helper->getIntervalDate(180)))
            ->addFieldToFilter(self::ACTITO_SYNC, 1)
            ->addFieldToFilter('product_type', array("nin" => ["simple", "bundle", "amgiftcard"]))
            ->addFieldToFilter('q.customer_id', array('notnull' => true))
            ->join(
                ["q" => "quote"],
                'main_table.quote_id = q.entity_id',
                ['customer_id']
            );

        echo $quoteItemCollection->getSelect() . "\r\n";

        foreach ($quoteItemCollection as $item) {
            if($item->getCustomerId()) {
                /** @var Task $taskQuoteItem */
                $taskQuoteItem = $this->taskFactory->create();

                /** @var Task $taskCustomer */
                $taskCustomer = $this->taskFactory->create();

                /** @var Task $taskQuote */
                $taskQuote = $this->taskFactory->create();


                try {
                    $taskQuoteItem->enqueue(
                        \Wetrust\Actito\Model\Flow\QuoteItem\Export::FLOW_ID,
                        ActitoHelper::TASK_DIRECTION_EXPORT,
                        $item->getId()
                    );
                    echo "creating task for quote Item " . $item->getItemId() . "\r\n";
                    $item->setActitoSync(0);
                    $item->save();

                    $taskCustomer->enqueue(
                        \Wetrust\Actito\Model\Flow\Customer\Export::FLOW_ID,
                        ActitoHelper::TASK_DIRECTION_EXPORT,
                        $item->getCustomerId()
                    );
                    echo "creating task for Customer " . $item->getCustomerId() . "\r\n";

                    $taskCustomer->enqueue(
                        \Wetrust\Actito\Model\Flow\Quote\Export::FLOW_ID,
                        ActitoHelper::TASK_DIRECTION_EXPORT,
                        $item->getQuoteId()
                    );
                    echo "creating task for Quote " . $item->getQuoteId() . "\r\n";

                } catch (\Exception $e) {
                    echo "## ERROR ##  " . $e->getMessage() . "\r\n";
                }
            }
            $item->setActitoSync(0);
            $item->save();
        }
    }


    public function handleNewsletterSubscriber()
    {

        echo "\r\n ------ handleNewsletterSubscriber ------ \r\n";


        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('newsletter_subscriber');

        $newsletterSubscriberCollection = $this->subscriberResource->create();

        if ($startEntityId = $this->helper->getFlowNewsletterSubscriberLastEntityId()) {
            $newsletterSubscriberCollection->addFieldToFilter('subscriber_id', ['gt' => $startEntityId]);
        }

        $newsletterSubscriberCollection
            ->addFieldToFilter(self::ACTITO_SYNC, 1);

        echo $newsletterSubscriberCollection->getSelect() . "\r\n";

        foreach ($newsletterSubscriberCollection as $subscriber) {

            $task = $this->taskFactory->create();
            try {
                $task->enqueue(
                    \Wetrust\Actito\Model\Flow\NewsletterSubscriber\Export::FLOW_ID,
                    ActitoHelper::TASK_DIRECTION_EXPORT,
                    $subscriber->getId()
                );

                $sql = "UPDATE " . $tableName . " SET actito_sync=0 WHERE subscriber_email='" . $subscriber->getSubscriberEmail() ."'";
                $result = $connection->query($sql);

                unset($task, $subscriber);
            } catch (\Exception $e) {
                echo "## ERROR ##  " . $e->getMessage() . "\r\n";
            }
        }
    }

    public function handleAlertStock() {
        return $this;
    }
}

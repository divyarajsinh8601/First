<?php declare(strict_types=1);

namespace Wetrust\Actito\Cron;

use Wetrust\Actito\Exception\ProcessException;
use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\FlowFactory;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory;
use Wetrust\Actito\Model\Task;

class Process
{
    /**
     * @var ActitoHelper
     */
    private $actitoHelper;

    /**
     * @var CollectionFactory
     */
    private $taskCollectionFactory;

    /**
     * @var FlowFactory
     */
    private $flowFactory;

    /**
     * Process constructor.
     * @param ActitoHelper $actitoHelper
     * @param CollectionFactory $taskCollectionFactory
     * @param FlowFactory $flowFactory
     */
    public function __construct(
        ActitoHelper $actitoHelper,
        CollectionFactory $taskCollectionFactory,
        FlowFactory $flowFactory
    )
    {
        $this->actitoHelper = $actitoHelper;
        $this->taskCollectionFactory = $taskCollectionFactory;
        $this->flowFactory = $flowFactory;
    }

    public function execute()
    {
        if (!$this->actitoHelper->isEnabled()) {
            return;
        }

        if ($this->canProcess()) {
            $this
                /** First call  */
                ->process()
                /** Retry */
                ->process(true);

        }
    }

    /**
     * Check if there are already tasks in state process
     *
     * @return bool
     */
    protected function canProcess()
    {
        $taskCollection = $this->taskCollectionFactory->create();
        $taskCollection
            ->addFieldToFilter('status', ActitoHelper::TASK_STATUS_PROCESSING)
            ->addFieldToFilter('last_start_at', ["lt" => $this->actitoHelper->getIntervalDate(5)]);

        if ($taskCollection->getSize() > 0) {
            return false;
        }
        return true;
    }

    /**
     * @param false $retry
     * @return $this
     */
    public function process($retry = false) {
        $taskCollection = $this->taskCollectionFactory->create();
        $taskCollection->addFieldToFilter('status', ActitoHelper::TASK_STATUS_PENDING);
        if($retry) {
            $taskCollection
                ->addFieldToFilter('last_start_at', ["lt" => $this->actitoHelper->getIntervalDate(60)])
                ->addFieldToFilter('retry_count', ['gt' => '0']);
            $taskCollection->getSelect()->limit(50);
        } else {
            $taskCollection->addFieldToFilter('retry_count', '0');
            $taskCollection->getSelect()->limit(1000);
        }

        $taskCollection->getSelect()->order('created_at DESC');

        echo "\r\n";
        echo $taskCollection->getSelect();
        echo "\r\n";

        /** @var Task $task */
        foreach ($taskCollection as $task) {
            $this->flowFactory
                ->setFlowId($task->getFlowId())
                ->setDirection($task->getDirection())
                ->process($task);
        }

        return $this;
    }


}

<?php

namespace Wetrust\Actito\Cron;

use Wetrust\Actito\Helper\Data as ActitoHelper;

class CleanHistory
{
    /**
     * @var ActitoHelper
     */
    protected $helper;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @param \Psr\Log\LoggerInterface $logger
     * @param ActitoHelper $helper
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        ActitoHelper $helper
    )
    {
        $this->logger = $logger;
        $this->helper = $helper;
    }

    /**
     * Execute the cron
     *
     * @return void
     */
    public function execute()
    {
        if ($this->helper->getHistoryClean()) {
            $this->logger->info("Cronjob CleanHistory is executed.");
            $this->helper->cleanHistory();
            $this->logger->info("Cronjob CleanHistory is end.");
        }


    }
}


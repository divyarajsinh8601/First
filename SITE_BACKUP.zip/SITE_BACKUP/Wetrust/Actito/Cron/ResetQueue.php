<?php declare (strict_types = 1);

namespace Wetrust\Actito\Cron;

use Wetrust\Actito\Helper\Data as ActitoHelper;
use Wetrust\Actito\Model\FlowFactory;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory;
use Wetrust\Actito\Model\Task;
use Wetrust\Actito\Model\TaskRepository;

class ResetQueue
{
    /**
     * @var ActitoHelper
     */
    private $actitoHelper;

    /**
     * @var CollectionFactory
     */
    private $taskCollectionFactory;

    /**
     * @var FlowFactory
     */
    private $flowFactory;

    /**
     * Process constructor.
     * @param ActitoHelper $actitoHelper
     * @param CollectionFactory $taskCollectionFactory
     * @param FlowFactory $flowFactory
     */
    public function __construct(
        ActitoHelper $actitoHelper,
        CollectionFactory $taskCollectionFactory,
        FlowFactory $flowFactory,
        TaskRepository $taskRepository
    ) {
        $this->actitoHelper = $actitoHelper;
        $this->taskCollectionFactory = $taskCollectionFactory;
        $this->flowFactory = $flowFactory;
        $this->_taskRepository = $taskRepository;
    }

    public function execute()
    {

        if (!$this->actitoHelper->isEnabled()) {
            return;
        }
        if ($this->actitoHelper->getResetInterval() != '') {
            $taskCollection = $this->taskCollectionFactory->create();
            $taskCollection->addFieldToFilter('status', ActitoHelper::TASK_STATUS_PROCESSING);
            $taskCollection->getSelect()->where(
                new \Zend_Db_Expr('TIME_TO_SEC(TIMEDIFF(CURRENT_TIMESTAMP, `last_start_at`)) >= ' . $this->actitoHelper->getResetInterval() * 60));
            foreach ($taskCollection as $taskData) {
                $task = $this->_taskRepository->get($taskData->getId());
                $task->reset();
            }
        }

    }
}

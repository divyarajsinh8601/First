<?php declare(strict_types=1);

namespace Wetrust\Actito\Exception;

class ProcessException extends \Exception
{

}

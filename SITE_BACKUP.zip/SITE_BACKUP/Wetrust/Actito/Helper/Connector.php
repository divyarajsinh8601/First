<?php declare(strict_types=1);

namespace Wetrust\Actito\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Serialize\Serializer\Json as JsonSerializer;
use Wetrust\Actito\Api\Data\TaskInterface;
use Wetrust\Actito\Exception\ProcessException;

class Connector extends AbstractHelper
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * @var bool
     */
    private $isCustomTable = false;

    /**
     * @var array
     */
    private $requestData = [];

    /**
     * @var string
     */
    private $table;

    /**
     * @var JsonSerializer
     */
    private $jsonSerializer;

    /**
     * @var TaskInterface
     */
    protected $task;

    /**
     * Connector constructor.
     * @param Context $context
     * @param Data $helper
     * @param JsonSerializer $jsonSerializer
     */
    public function __construct(
        Context $context,
        Data $helper,
        JsonSerializer $jsonSerializer
    )
    {
        $this->helper = $helper;
        $this->jsonSerializer = $jsonSerializer;
        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isCustomTable(): bool
    {
        return $this->isCustomTable;
    }

    /**
     * @return array
     */
    public function getRequestData(): array
    {
        return $this->requestData;
    }

    /**
     * @param string $attribute
     * @param string $value
     * @param string|int $type
     *
     * @return $this
     */
    public function addRequestData(string $attribute, $value, string $type = 'POST'): Connector
    {
        if ($this->isCustomTable()) {
            switch ($type) {
                case 'POST':
                    $this->requestData['properties'][] = [
                        'name' => $attribute,
                        'value' => $value
                    ];
                    break;
                default:
                    $this->requestData['searchField'] = $attribute;
                    $this->requestData['searchValue'] = $value;
            }
        } else {
            $this->requestData['attributes'][] = [
                'name' => $attribute,
                'value' => $value
            ];
        }

        return $this;
    }

    /**
     * @param $attribute
     * @param $value
     */
    public function addRequestSubscription($attribute, $value)
    {
        $this->requestData['subscriptions'][] = [
            'name' => $attribute,
            'subscribe' => $value
        ];
    }

    /**
     * @param bool $isCustomTable
     * @return $this
     */
    public function setIsCustomTable(bool $isCustomTable = false): Connector
    {
        $this->isCustomTable = $isCustomTable;

        return $this;
    }

    /**
     * @param TaskInterface $task
     * @return $this
     */
    public function setTask(TaskInterface $task): Connector
    {
        $this->task = $task;

        return $this;
    }

    /**
     * @return TaskInterface
     */
    public function getTask() {
        return $this->task;
    }
    /**
     * @param string $table
     * @return $this
     */
    public function setTable(string $table): Connector
    {
        $this->table = $table;

        return $this;
    }

    /**
     * @return string
     */
    public function getTable(): string
    {
        return $this->table;
    }

    /**
     * @return $this
     */
    public function pushData(): Connector
    {
        if ($this->helper->isEnabled()) {
            $this->task->addRequest(print_r($this->getRequestData(), true));
            $result = $this->request($this->jsonSerializer->serialize($this->getRequestData()));
            $response = $this->jsonSerializer->unserialize($result);
            if (isset($response['status'])) {
                throw new ProcessException($response['status'] . " - " . $response['message']);
            }
            $this->task->success($result);
        }

        return $this;
    }

    public function getData()
    {
        if ($this->helper->isEnabled()) {
            $this->task->addRequest(print_r($this->getRequestData(), true));
            $result = $this->request($this->getRequestData(), 'GET');

            return $this->jsonSerializer->unserialize($result);
        }
    }

    /**
     * @param string|array $data
     * @param string $type
     * @return bool|string
     */
    protected function request($data, string $type = 'POST')
    {
        $license = $this->helper->getLicense();
        $accessName = $this->helper->getAccessName();
        $password = $this->helper->getPassword();
        $url = $this->getEntityUrl($type);

        $this->helper->log($url, 'info');

        if (!empty($data) && strtoupper($type) == 'GET') {
            $url .= '?' . http_build_query($data);
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_USERPWD, "{$license}/{$accessName}:{$password}");
        curl_setopt($ch, CURLOPT_TIMEOUT, 50);
        if ($type == 'POST') {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        } else {
            curl_setopt($ch, CURLOPT_HEADER, false);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        unset($this->requestData);
        return $response;
    }

    /**
     * @param string $type
     * @return string
     */
    protected function getEntityUrl($type = 'POST'): string
    {
        $url = $this->helper->getUrl();
        $entity = $this->helper->getEntity();
        $table = $this->getTable();

        if ($this->isCustomTable()) {
            switch ($type) {
                case 'POST':
                    $url .= "entity/{$entity}/customTable/{$table}/record?allowUpdate=true";
                    break;
                default:
                    $url .= "entity/{$entity}/customTable/{$table}/record";
                    break;
            }
        } else {
            $url .= "entity/{$entity}/table/{$table}/profile";
        }

        return $url;
    }
}

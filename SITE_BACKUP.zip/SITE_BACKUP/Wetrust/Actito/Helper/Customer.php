<?php declare(strict_types=1);

namespace Wetrust\Actito\Helper;

use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory as OrderCollectionFactory;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Wetrust\Actito\Logger\Logger;
use Magento\SalesRule\Model\CouponFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory;

class Customer extends Data
{
    /**
     * @var OrderCollectionFactory
     */
    protected $orderCollectionFactory;

    /**
         * @var CollectionFactory
         */
        protected $collectionFactory;

    /**
     * Customer constructor.
     * @param Context $context
     * @param Logger $logger
     * @param DateTimeFactory $dateTimeFactory
     * @param TimezoneInterface $timezoneInterface
     * @param ProductCollectionFactory $productCollectionFactory
     * @param CouponFactory $couponFactory
     * @param \Magento\ProductAlert\Model\ResourceModel\Stock\CollectionFactory $stockCollectionFactory
     * @param Configurable $configurableModel
     * @param Image $helperImportorderCollectionFactory
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        Context $context,
        Logger $logger,
        DateTimeFactory $dateTimeFactory,
        TimezoneInterface $timezoneInterface,
        ProductCollectionFactory $productCollectionFactory,
        CouponFactory $couponFactory,
        \Magento\ProductAlert\Model\ResourceModel\Stock\CollectionFactory $stockCollectionFactory,
        Configurable $configurableModel,
        Image $helperImport,
        OrderCollectionFactory $orderCollectionFactory,
        CollectionFactory $collectionFactory
    ) {
        $this->orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context, $logger, $dateTimeFactory, $timezoneInterface, $productCollectionFactory,
            $couponFactory, $stockCollectionFactory, $configurableModel, $helperImport, $collectionFactory);
    }


    /**
     * @param \Magento\Customer\Model\Customer $customer
     * @return \Magento\Framework\DataObject
     */
    public function getLastOrder(\Magento\Customer\Model\Customer $customer)
    {
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addAttributeToFilter('customer_id', $customer->getId())
            ->addAttributeToFilter('status', ['in' => ['complete', 'processing']]);

        $orderCollection->getSelect()->order('created_at DESC');

        return $orderCollection->getFirstItem();
    }

    /**
     * @param \Magento\Customer\Model\Customer $customer
     * @return \Magento\Framework\DataObject
     */
    public function getFirstOrder(\Magento\Customer\Model\Customer $customer)
    {
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addAttributeToFilter('customer_id', $customer->getId())
            ->addAttributeToFilter('status', ['in' => ['complete', 'processing']]);

        $orderCollection->getSelect()->order('created_at ASC');

        return $orderCollection->getFirstItem();
    }


}

<?php declare(strict_types=1);

namespace Wetrust\Actito\Helper;

use Magento\Catalog\Helper\Image;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Stdlib\DateTime\DateTimeFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\SalesRule\Model\CouponFactory;
use Wetrust\Actito\Logger\Logger;
use Wetrust\Actito\Model\ResourceModel\Task\CollectionFactory;

class Data extends AbstractHelper
{
    const XML_PATH_ENABLED = 'actito/general/enabled';
    const XML_PATH_URL = 'actito/general/url';
    const XML_PATH_PASSWORD = 'actito/general/password';
    const XML_PATH_ENTITY = 'actito/general/entity';
    const XML_PATH_LICENSE = 'actito/general/license';
    const XML_PATH_ACCESS_NAME = 'actito/general/access_name';
    const XML_PATH_TRIES_BEFORE_ERROR = 'actito/general/tries_before_error';
    const XML_PATH_INTERVAL = 'actito/general/interval';
    const XML_PATH_RESET_INTERVAL = 'actito/general/reset_interval';
    const XML_PATH_MOTHER_LANGUAGE = 'actito/general/mother_language';

    const XML_PATH_FLOW_CUSTOMER_ENABLED = 'actito/flow_customer/enabled';
    const XML_PATH_FLOW_CUSTOMER_INTERVAL = 'actito/flow_customer/interval';
    const XML_PATH_FLOW_CUSTOMER_TABLE_NAME = 'actito/flow_customer/table_name';
    const XML_PATH_FLOW_CUSTOMER_LAST_ENTITY = 'actito/flow_customer/last_entity';
    const XML_PATH_FLOW_CUSTOMER_LAST_RUN = 'actito/flow_customer/last_run';

    const XML_PATH_FLOW_QUOTE_ENABLED = 'actito/flow_quote/enabled';
    const XML_PATH_FLOW_QUOTE_INTERVAL = 'actito/flow_quote/interval';
    const XML_PATH_FLOW_QUOTE_TABLE_NAME = 'actito/flow_quote/table_name';
    const XML_PATH_FLOW_QUOTE_LAST_ENTITY = 'actito/flow_quote/last_entity';
    const XML_PATH_FLOW_QUOTE_LAST_RUN = 'actito/flow_quote/last_run';

    const XML_PATH_FLOW_QUOTE_ITEM_ENABLED = 'actito/flow_quote_item/enabled';
    const XML_PATH_FLOW_QUOTE_ITEM_INTERVAL = 'actito/flow_quote_item/interval';
    const XML_PATH_FLOW_QUOTE_ITEM_TABLE_NAME = 'actito/flow_quote_item/table_name';
    const XML_PATH_FLOW_QUOTE_ITEM_LAST_ENTITY = 'actito/flow_quote_item/last_entity';
    const XML_PATH_FLOW_QUOTE_ITEM_LAST_RUN = 'actito/flow_quote_item/last_run';

    const XML_PATH_FLOW_ORDER_ITEM_ENABLED = 'actito/flow_order_item/enabled';
    const XML_PATH_FLOW_ORDER_ITEM_INTERVAL = 'actito/flow_order_item/interval';
    const XML_PATH_FLOW_ORDER_ITEM_TABLE_NAME = 'actito/flow_order_item/table_name';
    const XML_PATH_FLOW_ORDER_ITEM_LAST_ENTITY = 'actito/flow_order_item/last_entity';
    const XML_PATH_FLOW_ORDER_ITEM_LAST_RUN = 'actito/flow_order_item/last_run';

    const XML_PATH_FLOW_ALERT_STOCK_ENABLED = 'actito/flow_alert_stock/enabled';
    const XML_PATH_FLOW_ALERT_STOCK_SEND_EMAIL = 'actito/flow_alert_stock/send_email';
    const XML_PATH_FLOW_ALERT_STOCK_INTERVAL = 'actito/flow_alert_stock/interval';
    const XML_PATH_FLOW_ALERT_STOCK_TABLE_NAME = 'actito/flow_alert_stock/table_name';
    const XML_PATH_FLOW_ALERT_STOCK_LAST_ENTITY = 'actito/flow_alert_stock/last_entity';
    const XML_PATH_FLOW_ALERT_STOCK_LAST_RUN = 'actito/flow_alert_stock/last_run';

    const XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_ENABLED = 'actito/flow_newsletter_subscriber/enabled';
    const XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_INTERVAL = 'actito/flow_newsletter_subscriber/interval';
    const XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_TABLE_NAME = 'actito/flow_newsletter_subscriber/table_name';
    const XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_LAST_ENTITY = 'actito/flow_newsletter_subscriber/last_entity';
    const XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_LAST_RUN = 'actito/flow_newsletter_subscriber/last_run';

    const XML_PATH_FLOW_HISTORY_CLEAN = 'actito/history/clean';
    const XML_PATH_FLOW_HISTORY_SUCCESS_LIFETIME = 'actito/history/success_lifetime';
    const XML_PATH_FLOW_HISTORY_ERROR_LIFETIME = 'actito/history/error_lifetime';

    const TASK_STATUS_PENDING = 'pending';
    const TASK_STATUS_ERROR = 'error';
    const TASK_STATUS_SUCCESS = 'success';
    const TASK_STATUS_PROCESSING = 'process';

    const TASK_DIRECTION_EXPORT = 'export';
    const TASK_DIRECTION_IMPORT = 'import';

    const PROFILE_SYNC_ENABLE = 1;
    const PROFILE_SYNC_DISABLE = 0;

    /**
     * Value of seconds in one minute
     */
    const SECONDS_IN_MINUTE = 60;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var DateTimeFactory
     */
    private $dateTimeFactory;

    /**
     * @var ProductCollectionFactory
     */
    private $productCollectionFactory;

    /**
     * @var CouponFactory
     */
    protected $couponFactory;

    /**
     * @var TimezoneInterface
     */
    protected $_timezoneInterface;

    /**
     * @var \Magento\ProductAlert\Model\ResourceModel\Stock\CollectionFactory
     */
    private $stockCollectionFactory;

    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    private $configurableModel;

    /**
     * @var Image
     */
    private $helperImport;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param Context $context
     * @param Logger $logger
     * @param DateTimeFactory $dateTimeFactory
     * @param TimezoneInterface $timezoneInterface
     * @param ProductCollectionFactory $productCollectionFactory
     * @param CouponFactory $couponFactory
     * @param \Magento\ProductAlert\Model\ResourceModel\Stock\CollectionFactory $stockCollectionFactory
     * @param Configurable $configurableModel
     * @param Image $helperImport
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        Context $context,
        Logger $logger,
        DateTimeFactory $dateTimeFactory,
        TimezoneInterface $timezoneInterface,
        ProductCollectionFactory $productCollectionFactory,
        CouponFactory $couponFactory,
        \Magento\ProductAlert\Model\ResourceModel\Stock\CollectionFactory $stockCollectionFactory,
        Configurable $configurableModel,
        Image $helperImport,
        CollectionFactory $collectionFactory
    )
    {
        $this->logger = $logger;
        $this->dateTimeFactory = $dateTimeFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->couponFactory = $couponFactory;
        $this->_timezoneInterface = $timezoneInterface;
        $this->stockCollectionFactory = $stockCollectionFactory;
        $this->configurableModel = $configurableModel;
        $this->helperImport = $helperImport;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    /**
     * @param $message
     * @param string $type
     */
    public function log($message, $type = 'log'): void
    {
        switch ($type) {
            case 'debug':
                $this->logger->debug($message);
                break;
            case 'info':
                $this->logger->info($message);
                break;
            case 'error':
                $this->logger->error($message);
                break;
            case 'log':
            default:
                $this->logger->notice($message);
        }
    }

    /**
     * @param string $date
     * @return string
     */
    public function formatDate(string $date): string
    {
        return $this->dateTimeFactory->create()->gmtDate('Y-m-d', $date);
    }

    /**
     * @param string $date
     * @return string
     */
    public function formatDateAndHour(string $date): string
    {
        return $this->dateTimeFactory->create()->gmtDate('Y-m-d H:i:s', $date);
    }

    /**
     * @param Product $product
     * @return float|int
     */
    public function getDiscountPercentForProduct($product)
    {
        $promotion = 0;
        if ($product->getPrice() && $product->getPrice() != 0) {
            $promotion = floor((($product->getPrice() - $product->getFinalPrice()) / $product->getPrice() * 10)) * 10;
            if ($promotion == 0) {
                $promotion = 0;
            }
        }
        return $promotion;
    }

    /***********************/
    /*  GET CONFIG VALUES  */
    /***********************/

    public function isEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ENABLED);
    }

    public function getUrl()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_URL);
    }

    public function getEntity()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ENTITY);
    }

    public function getLicense()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_LICENSE);
    }

    public function getAccessName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ACCESS_NAME);
    }

    public function getPassword()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_PASSWORD);
    }

    public function getMaxRetryBeforeError()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_TRIES_BEFORE_ERROR);
    }

    public function getInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_INTERVAL);
    }

    public function getResetInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_RESET_INTERVAL);
    }

    public function getMappingCustomer()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_TABLE_NAME);
    }

    public function getMappingQuoteItem()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_TABLE_NAME);
    }

    public function getMappingQuote()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_TABLE_NAME);
    }

    public function getMappingOrderItem()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_TABLE_NAME);
    }

    public function getMappingAlertStock()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_TABLE_NAME);
    }

    public function getEnabledFlows($returnOnlyEnabled = false)
    {
        $enabledFlows = [
            \Wetrust\Actito\Model\Flow\Customer\Export::FLOW_ID => $this->getFlowCustomerEnabled(),
            \Wetrust\Actito\Model\Flow\OrderItem\Export::FLOW_ID => $this->getFlowOrderItemEnabled(),
            \Wetrust\Actito\Model\Flow\QuoteItem\Export::FLOW_ID => $this->getFlowQuoteItemEnabled(),
            \Wetrust\Actito\Model\Flow\NewsletterSubscriber\Export::FLOW_ID => $this->getFlowNewsletterSubscriberEnabled(),
            \Wetrust\Actito\Model\Flow\AlertStock\Export::FLOW_ID => $this->getFlowNewsletterSubscriberEnabled(),

        ];

        if ($returnOnlyEnabled) {
            $enabledFlows = array_diff($enabledFlows, [null]);
        }

        return $enabledFlows;
    }

    public function getFlowCustomerEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_ENABLED);
    }

    public function getFlowCustomerInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_INTERVAL);
    }

    public function getFlowCustomerLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_LAST_ENTITY);
    }

    public function getFlowCustomerLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_LAST_RUN);
    }

    public function getFlowCustomerTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_CUSTOMER_TABLE_NAME);
    }

    public function getFlowQuoteItemEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_ENABLED);
    }

    public function getFlowQuoteItemInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_INTERVAL);
    }

    public function getFlowQuoteItemLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_LAST_ENTITY);
    }

    public function getFlowQuoteItemLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_LAST_RUN);
    }

    public function getFlowQuoteItemTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ITEM_TABLE_NAME);
    }

    public function getFlowQuoteEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_ENABLED);
    }

    public function getFlowQuoteInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_INTERVAL);
    }

    public function getFlowQuoteLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_LAST_ENTITY);
    }

    public function getFlowQuoteLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_LAST_RUN);
    }

    public function getFlowQuoteTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_QUOTE_TABLE_NAME);
    }

    public function getFlowOrderItemEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_ENABLED);
    }

    public function getFlowOrderItemInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_INTERVAL);
    }

    public function getFlowOrderItemLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_LAST_ENTITY);
    }

    public function getFlowOrderItemLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_LAST_RUN);
    }

    public function getFlowOrderItemTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ORDER_ITEM_TABLE_NAME);
    }

    public function getFlowAlertStockEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_ENABLED);
    }

    public function getFlowAlertStockSendEmail()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_SEND_EMAIL);
    }

    public function getFlowAlertStockInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_INTERVAL);
    }

    public function getFlowAlertStockLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_LAST_ENTITY);
    }

    public function getFlowAlertStockLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_LAST_RUN);
    }

    public function getFlowAlertStockTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_ALERT_STOCK_TABLE_NAME);
    }

    public function getFlowNewsletterSubscriberEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_ENABLED);
    }

    public function getFlowNewsletterSubscriberInterval()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_INTERVAL);
    }

    public function getFlowNewsletterSubscriberLastEntityId()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_LAST_ENTITY);
    }

    public function getFlowNewsletterSubscriberLastRun()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_LAST_RUN);
    }

    public function getFlowNewsletterSubscriberTableName()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_NEWSLETTER_SUBSCRIBER_TABLE_NAME);
    }

    public function getMotherLanguage($storeId = null)
    {
        return $this->scopeConfig->getValue(self::XML_PATH_MOTHER_LANGUAGE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * @param $email
     * @param $prefix
     * @return false
     */
    public function getPrefixedCouponCodeByEmail($email, $prefix)
    {
        $coupon = $this->couponFactory
            ->create()
            ->getCollection()
            ->addFieldToFilter('assigned_to_email', $email)
            ->addFieldToFilter('code', ['like' => $prefix . "%"])
            ->getFirstItem();

        if ($coupon->getId()) {
            // check entire usage limit
            if ($coupon->getUsageLimit() && $coupon->getTimesUsed() >= $coupon->getUsageLimit()) {
                return false;
            }
            return $coupon->getCode();
        }
        return false;
    }

    /**
     * @return string
     */
    public function getIntervalDate($interval, $unit = "minutes"): string
    {
        $currentDateTime = date('Y-m-d H:i:s');

        return $this->_timezoneInterface->date(strtotime($currentDateTime . " -{$interval} {$unit}"))->format('Y-m-d H:i:s');
    }

    /**
     * @return \Magento\ProductAlert\Model\ResourceModel\Stock\Collection
     */
    public function getAlertStockCollection()
    {
        return $this->stockCollectionFactory->create()
            //->addFieldToFilter('status', 0)
            ->setCustomerOrder();
    }

    public function getParentProduct($childId)
    {
        $parentId = $this->configurableModel->getParentIdsByChild($childId);
        return $this->productCollectionFactory->create()
            ->addAttributeToSelect([
                'name',
                'small_image',
                'color',
                'price',
                'fina_price',
                'image'
            ])
            ->addFieldToFilter('entity_id', $parentId)
            ->getFirstItem();
    }

    public function getImage($product, $image)
    {
        $finalProduct = $product;
        if ($product->getTypeId() === "simple") {
            $finalProduct = $this->getImage($this->getParentProduct($product->getId()));
        }
        return $this->helperImport->init($finalProduct, 'product_page_image_small')
            ->setImageFile($image)
            ->getUrl();
    }

    public function getDateNow()
    {
        return $this->_timezoneInterface->date()->format('Y-m-d H:i:s');
    }

    public function getHistoryClean()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_HISTORY_CLEAN);
    }

    public function getHistorySuccessLifetime()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_HISTORY_SUCCESS_LIFETIME);
    }

    public function getHistoryErrorLifetime()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_FLOW_HISTORY_ERROR_LIFETIME);
    }

    public function cleanHistory()
    {
        return $this->cleanHistoryByStatus("success", $this->getHistorySuccessLifetime())->cleanHistoryByStatus("error", $this->getHistoryErrorLifetime());
    }

    public function cleanHistoryByStatus($status, $days)
    {
        try {
            $queryExpr = new \Zend_Db_Expr('created_at < UTC_TIMESTAMP() - INTERVAL ' . $days . ' DAY');
            $collection = $this->collectionFactory->create();
            $collection->addFieldToFilter('status', $status);
            $collection->getSelect()->where($queryExpr);

            $i = 0;
            foreach ($collection as $task) {
                $task->delete();
                $i++;
            }
        } catch (Exception $e) {
            $this->logger->error(
                sprintf('Task has an error: %s.', $e->getMessage())
            );
        }

        return $this;
    }
}
